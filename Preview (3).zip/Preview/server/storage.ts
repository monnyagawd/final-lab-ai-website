import { 
  users, 
  type User, 
  type InsertUser, 
  type Contact, 
  type InsertContact,
  type Appointment,
  type InsertAppointment,
  type AvailableSlot,
  type InsertAvailableSlot,
  type WebsiteAnalytics,
  type InsertWebsiteAnalytics,
  type SocialMediaAccount,
  type InsertSocialMediaAccount,
  type Notification,
  type InsertNotification,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type Shipment,
  type InsertShipment,
  type ShippingProvider,
  type InsertShippingProvider,
  type InventoryItem,
  type InsertInventoryItem,
  type SocialConnection,
  type InsertSocialConnection,
  type EcommerceConnection,
  type InsertEcommerceConnection,
  type TrackedWebsite,
  type InsertTrackedWebsite,
  type PageView,
  type InsertPageView,
  type Event,
  type InsertEvent
} from "@shared/schema";
import session from "express-session";
import { format } from 'date-fns';

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(id: number, updates: Partial<User>): Promise<User | undefined>;
  updateStripeCustomerId(userId: number, stripeCustomerId: string): Promise<User | undefined>;
  updateUserStripeInfo(userId: number, stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }): Promise<User | undefined>;
  
  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;
  
  // Appointment methods
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointmentById(id: number): Promise<Appointment | undefined>;
  getAppointmentsByEmail(email: string): Promise<Appointment[]>;
  getAllAppointments(): Promise<Appointment[]>;
  updateAppointmentStatus(id: number, status: string): Promise<Appointment | undefined>;
  
  // Available slots methods
  getAvailableSlotsByDate(date: string): Promise<AvailableSlot[]>;
  createAvailableSlot(slot: InsertAvailableSlot): Promise<AvailableSlot>;
  updateSlotAvailability(id: number, isAvailable: boolean): Promise<AvailableSlot | undefined>;
  bulkCreateDefaultSlots(date: string, timeSlots: string[]): Promise<AvailableSlot[]>;
  
  // Website Analytics methods
  getWebsiteAnalytics(userId: number): Promise<WebsiteAnalytics | undefined>;
  createWebsiteAnalytics(analytics: InsertWebsiteAnalytics): Promise<WebsiteAnalytics>;
  updateWebsiteAnalytics(id: number, updates: Partial<WebsiteAnalytics>): Promise<WebsiteAnalytics | undefined>;
  
  // Social Media Account methods
  getSocialMediaAccounts(userId: number): Promise<SocialMediaAccount[]>;
  getSocialMediaAccountById(id: number): Promise<SocialMediaAccount | undefined>;
  getSocialMediaAccountByPlatform(userId: number, platform: string): Promise<SocialMediaAccount | undefined>;
  createSocialMediaAccount(account: InsertSocialMediaAccount): Promise<SocialMediaAccount>;
  updateSocialMediaAccount(id: number, updates: Partial<SocialMediaAccount>): Promise<SocialMediaAccount | undefined>;
  
  // Notification methods
  getUserNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  deleteNotification(id: number): Promise<boolean>;

  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Order methods
  getAllOrders(): Promise<Order[]>;
  getUserOrders(userId: number): Promise<Order[]>;
  getOrderById(id: number): Promise<Order | undefined>;
  getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined>;
  
  // Order Item methods
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Shipment methods
  getShipmentsByOrder(orderId: number): Promise<Shipment[]>;
  getShipmentById(id: number): Promise<Shipment | undefined>;
  getShipmentByTrackingNumber(trackingNumber: string): Promise<Shipment | undefined>;
  createShipment(shipment: InsertShipment): Promise<Shipment>;
  updateShipment(id: number, updates: Partial<Shipment>): Promise<Shipment | undefined>;
  
  // Shipping Provider methods
  getAllShippingProviders(): Promise<ShippingProvider[]>;
  getShippingProviderById(id: number): Promise<ShippingProvider | undefined>;
  getShippingProviderByName(name: string): Promise<ShippingProvider | undefined>;
  createShippingProvider(provider: InsertShippingProvider): Promise<ShippingProvider>;
  updateShippingProvider(id: number, updates: Partial<ShippingProvider>): Promise<ShippingProvider | undefined>;
  toggleShippingProviderStatus(id: number, active: boolean): Promise<ShippingProvider | undefined>;
  
  // Inventory methods
  getUserInventoryItems(userId: number): Promise<InventoryItem[]>;
  getInventoryItemById(id: number): Promise<InventoryItem | undefined>;
  getInventoryItemBySku(userId: number, sku: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, updates: Partial<InventoryItem>): Promise<InventoryItem | undefined>;
  updateInventoryQuantity(id: number, quantityChange: number): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;
  
  // External Integration: Social Media Connections
  getSocialConnections(userId: number): Promise<SocialConnection[]>;
  getSocialConnectionByPlatform(userId: number, platform: string): Promise<SocialConnection | undefined>;
  createSocialConnection(connection: InsertSocialConnection): Promise<SocialConnection>;
  updateSocialConnection(id: number, updates: Partial<SocialConnection>): Promise<SocialConnection | undefined>;
  
  // External Integration: E-commerce Connections
  getEcommerceConnections(userId: number): Promise<EcommerceConnection[]>;
  getEcommerceConnectionByPlatform(userId: number, platform: string): Promise<EcommerceConnection | undefined>;
  createEcommerceConnection(connection: InsertEcommerceConnection): Promise<EcommerceConnection>;
  updateEcommerceConnection(id: number, updates: Partial<EcommerceConnection>): Promise<EcommerceConnection | undefined>;
  
  // External Integration: Website Tracking
  getTrackedWebsites(userId: number): Promise<TrackedWebsite[]>;
  getTrackedWebsiteById(id: number): Promise<TrackedWebsite | undefined>;
  getTrackedWebsiteByTrackingId(trackingId: string): Promise<TrackedWebsite | undefined>;
  getTrackedWebsiteByDomain(userId: number, domain: string): Promise<TrackedWebsite | undefined>;
  createTrackedWebsite(website: InsertTrackedWebsite): Promise<TrackedWebsite>;
  
  // External Integration: Analytics Data
  recordPageView(pageView: InsertPageView): Promise<PageView>;
  recordEvent(event: InsertEvent): Promise<Event>;
  getPageViewsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<PageView[]>;
  getEventsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<Event[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private appointments: Map<number, Appointment>;
  private availableSlots: Map<number, AvailableSlot>;
  private websiteAnalytics: Map<number, WebsiteAnalytics>;
  private socialMediaAccounts: Map<number, SocialMediaAccount>;
  private notifications: Map<number, Notification>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private shipments: Map<number, Shipment>;
  private shippingProviders: Map<number, ShippingProvider>;
  private inventoryItems: Map<number, InventoryItem>;
  
  // External integration storage
  private socialConnections: Map<number, SocialConnection>;
  private ecommerceConnections: Map<number, EcommerceConnection>;
  private trackedWebsites: Map<number, TrackedWebsite>;
  private pageViews: Map<number, PageView>;
  private events: Map<number, Event>;
  
  private userCurrentId: number;
  private contactCurrentId: number;
  private appointmentCurrentId: number;
  private availableSlotCurrentId: number;
  private websiteAnalyticsCurrentId: number;
  private socialMediaAccountCurrentId: number;
  private notificationCurrentId: number;
  private productCurrentId: number;
  private orderCurrentId: number;
  private orderItemCurrentId: number;
  private shipmentCurrentId: number;
  private shippingProviderCurrentId: number;
  private inventoryItemCurrentId: number;
  
  // External integration IDs
  private socialConnectionCurrentId: number;
  private ecommerceConnectionCurrentId: number;
  private trackedWebsiteCurrentId: number;
  private pageViewCurrentId: number;
  private eventCurrentId: number;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.appointments = new Map();
    this.availableSlots = new Map();
    this.websiteAnalytics = new Map();
    this.socialMediaAccounts = new Map();
    this.notifications = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.shipments = new Map();
    this.shippingProviders = new Map();
    this.inventoryItems = new Map();
    
    // Initialize external integration storage
    this.socialConnections = new Map();
    this.ecommerceConnections = new Map();
    this.trackedWebsites = new Map();
    this.pageViews = new Map();
    this.events = new Map();
    
    this.userCurrentId = 1;
    this.contactCurrentId = 1;
    this.appointmentCurrentId = 1;
    this.availableSlotCurrentId = 1;
    this.websiteAnalyticsCurrentId = 1;
    this.socialMediaAccountCurrentId = 1;
    this.notificationCurrentId = 1;
    this.productCurrentId = 1;
    this.orderCurrentId = 1;
    this.orderItemCurrentId = 1;
    this.shipmentCurrentId = 1;
    this.shippingProviderCurrentId = 1;
    this.inventoryItemCurrentId = 1;
    
    // Initialize external integration IDs
    this.socialConnectionCurrentId = 1;
    this.ecommerceConnectionCurrentId = 1;
    this.trackedWebsiteCurrentId = 1;
    this.pageViewCurrentId = 1;
    this.eventCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = {
      ...insertUser,
      id,
      role: "customer",
      createdAt: new Date().toISOString(),
      websiteStatus: "offline",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      websiteUrl: null,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      companyName: insertUser.companyName || null,
      websiteName: insertUser.websiteName || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserProfile(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateStripeCustomerId(userId: number, stripeCustomerId: string): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, stripeCustomerId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserStripeInfo(
    userId: number, 
    stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }
  ): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      stripeCustomerId: stripeInfo.stripeCustomerId,
      stripeSubscriptionId: stripeInfo.stripeSubscriptionId
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  // Contact methods
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactCurrentId++;
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: new Date().toISOString() 
    };
    this.contacts.set(id, contact);
    return contact;
  }
  
  async getAllContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }
  
  // Appointment methods
  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentCurrentId++;
    const newAppointment: Appointment = {
      ...appointment,
      id,
      status: "scheduled",
      createdAt: new Date().toISOString()
    };
    this.appointments.set(id, newAppointment);
    return newAppointment;
  }
  
  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async getAppointmentsByEmail(email: string): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.email === email
    );
  }
  
  async getAllAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }
  
  async updateAppointmentStatus(id: number, status: string): Promise<Appointment | undefined> {
    const appointment = await this.getAppointmentById(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, status };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }
  
  // AvailableSlots methods
  async getAvailableSlotsByDate(date: string): Promise<AvailableSlot[]> {
    return Array.from(this.availableSlots.values()).filter(
      (slot) => slot.date === date && slot.isAvailable
    );
  }
  
  async createAvailableSlot(slot: InsertAvailableSlot): Promise<AvailableSlot> {
    const id = this.availableSlotCurrentId++;
    const newSlot: AvailableSlot = {
      ...slot,
      id,
      isAvailable: slot.isAvailable ?? true, // Ensure isAvailable is set
      createdAt: new Date().toISOString()
    };
    this.availableSlots.set(id, newSlot);
    return newSlot;
  }
  
  async updateSlotAvailability(id: number, isAvailable: boolean): Promise<AvailableSlot | undefined> {
    const slot = this.availableSlots.get(id);
    if (!slot) return undefined;
    
    const updatedSlot = { ...slot, isAvailable };
    this.availableSlots.set(id, updatedSlot);
    return updatedSlot;
  }
  
  async bulkCreateDefaultSlots(date: string, timeSlots: string[]): Promise<AvailableSlot[]> {
    const createdSlots: AvailableSlot[] = [];
    
    for (const timeSlot of timeSlots) {
      const slot = await this.createAvailableSlot({
        date,
        timeSlot,
        isAvailable: true
      });
      createdSlots.push(slot);
    }
    
    return createdSlots;
  }
  
  // Website Analytics methods
  async getWebsiteAnalytics(userId: number): Promise<WebsiteAnalytics | undefined> {
    return Array.from(this.websiteAnalytics.values()).find(
      (analytics) => analytics.userId === userId
    );
  }
  
  async createWebsiteAnalytics(analytics: InsertWebsiteAnalytics): Promise<WebsiteAnalytics> {
    const id = this.websiteAnalyticsCurrentId++;
    const newAnalytics: WebsiteAnalytics = {
      id,
      userId: analytics.userId,
      // Core metrics
      pageViews: analytics.pageViews || "0",
      uniqueVisitors: analytics.uniqueVisitors || "0",
      bounceRate: analytics.bounceRate || "0",
      avgTimeOnSite: analytics.avgTimeOnSite || "0",
      
      // Time periods
      dailyVisitors: analytics.dailyVisitors || "0",
      weeklyVisitors: analytics.weeklyVisitors || "0",
      monthlyVisitors: analytics.monthlyVisitors || "0",
      
      // Page and referral data
      topReferrers: analytics.topReferrers || null,
      topPages: analytics.topPages || null,
      topCountries: analytics.topCountries || null,
      topCities: analytics.topCities || null,
      
      // Real-time data
      currentVisitors: analytics.currentVisitors || "0",
      
      // Device data
      deviceBreakdown: analytics.deviceBreakdown || null,
      
      // Conversion data
      conversionRate: analytics.conversionRate || "0",
      
      // SEO data
      seoSummary: analytics.seoSummary || null,
      
      // Heatmap data
      heatmapData: analytics.heatmapData || null,
      
      // Traffic trend data
      trafficTrend: analytics.trafficTrend || null,
      
      lastUpdated: new Date().toISOString()
    };
    this.websiteAnalytics.set(id, newAnalytics);
    return newAnalytics;
  }
  
  async updateWebsiteAnalytics(id: number, updates: Partial<WebsiteAnalytics>): Promise<WebsiteAnalytics | undefined> {
    const analytics = this.websiteAnalytics.get(id);
    if (!analytics) return undefined;
    
    const updatedAnalytics = { 
      ...analytics, 
      ...updates,
      lastUpdated: new Date().toISOString()
    };
    this.websiteAnalytics.set(id, updatedAnalytics);
    return updatedAnalytics;
  }
  
  // Social Media Account methods
  async getSocialMediaAccounts(userId: number): Promise<SocialMediaAccount[]> {
    return Array.from(this.socialMediaAccounts.values()).filter(
      (account) => account.userId === userId
    );
  }
  
  async getSocialMediaAccountById(id: number): Promise<SocialMediaAccount | undefined> {
    return this.socialMediaAccounts.get(id);
  }
  
  async getSocialMediaAccountByPlatform(userId: number, platform: string): Promise<SocialMediaAccount | undefined> {
    return Array.from(this.socialMediaAccounts.values()).find(
      (account) => account.userId === userId && account.platform === platform
    );
  }
  
  async createSocialMediaAccount(account: InsertSocialMediaAccount): Promise<SocialMediaAccount> {
    const id = this.socialMediaAccountCurrentId++;
    const newAccount: SocialMediaAccount = {
      id,
      userId: account.userId,
      platform: account.platform,
      accountId: account.accountId ?? null,
      accountName: account.accountName ?? null,
      accessToken: account.accessToken ?? null,
      refreshToken: account.refreshToken ?? null,
      tokenExpiry: null,
      
      // Core metrics
      followers: "0",
      following: "0",
      engagement: "0",
      profileViews: "0",
      impressions: "0",
      
      // Engagement metrics
      likes: "0",
      comments: "0",
      shares: "0",
      posts: "0",
      
      // Content performance
      recentPostData: null,
      topPerformingPosts: null,
      
      // Growth metrics
      growthRate: "0",
      followersHistory: null,
      
      // Reach and visibility
      topPostReach: "0",
      storyViews: "0",
      
      // Click metrics
      clickThroughRate: "0",
      linkClicks: "0",
      
      // Audience data
      demographicData: null,
      audienceInterests: null,
      
      // Conversions
      conversionRate: "0",
      
      // Platform-specific metrics
      // Discord
      serverMembers: "0",
      activeUsers: "0",
      messagesSent: "0",
      
      // TikTok
      videoViews: "0",
      videoCompletion: "0",
      
      // Twitter/X
      retweets: "0",
      mentions: "0",
      
      // Tracking
      mentionsTrackingData: null,
      tagsTrackingData: null,
      
      // Summary reports
      weeklyReportData: null,
      monthlyReportData: null,
      
      lastFetched: new Date().toISOString()
    };
    this.socialMediaAccounts.set(id, newAccount);
    return newAccount;
  }
  
  async updateSocialMediaAccount(id: number, updates: Partial<SocialMediaAccount>): Promise<SocialMediaAccount | undefined> {
    const account = this.socialMediaAccounts.get(id);
    if (!account) return undefined;
    
    const updatedAccount = { 
      ...account, 
      ...updates,
      lastFetched: new Date().toISOString()
    };
    this.socialMediaAccounts.set(id, updatedAccount);
    return updatedAccount;
  }
  
  // Notification methods
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.userId === userId
    );
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = this.notificationCurrentId++;
    const newNotification: Notification = {
      id,
      userId: notification.userId,
      title: notification.title,
      message: notification.message,
      type: notification.type,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    this.notifications.set(id, newNotification);
    return newNotification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, isRead: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  async deleteNotification(id: number): Promise<boolean> {
    return this.notifications.delete(id);
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productCurrentId++;
    const newProduct: Product = {
      ...product,
      id,
      description: product.description || null,
      category: product.category || null,
      sku: product.sku || null,
      inventoryCount: product.inventoryCount || 0,
      imageUrl: product.imageUrl || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product, 
      ...updates,
      updatedAt: new Date().toISOString() 
    };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Order methods
  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getUserOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined> {
    return Array.from(this.orders.values()).find(
      (order) => order.orderNumber === orderNumber
    );
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    
    // Generate unique order number if not provided
    const orderNumber = order.orderNumber || `ORD-${Date.now()}-${id}`;
    
    const newOrder: Order = {
      ...order,
      id,
      orderNumber,
      orderDate: order.orderDate || new Date().toISOString(),
      status: order.status || "pending",
      paymentStatus: order.paymentStatus || "paid",
      shippingCountry: order.shippingCountry || "United States",
      billingAddress: order.billingAddress || null,
      billingCity: order.billingCity || null,
      billingState: order.billingState || null,
      billingZip: order.billingZip || null,
      billingCountry: order.billingCountry || null,
      customerPhone: order.customerPhone || null,
      customerNotes: order.customerNotes || null,
      internalNotes: order.internalNotes || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { 
      ...order, 
      status,
      updatedAt: new Date().toISOString() 
    };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { 
      ...order, 
      ...updates,
      updatedAt: new Date().toISOString() 
    };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
  
  // Order Item methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId
    );
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemCurrentId++;
    const newOrderItem = {
      ...orderItem,
      id,
      productId: orderItem.productId,
      createdAt: new Date().toISOString()
    } as OrderItem;
    this.orderItems.set(id, newOrderItem);
    return newOrderItem;
  }
  
  // Shipment methods
  async getShipmentsByOrder(orderId: number): Promise<Shipment[]> {
    return Array.from(this.shipments.values()).filter(
      (shipment) => shipment.orderId === orderId
    );
  }

  async getShipmentById(id: number): Promise<Shipment | undefined> {
    return this.shipments.get(id);
  }

  async getShipmentByTrackingNumber(trackingNumber: string): Promise<Shipment | undefined> {
    return Array.from(this.shipments.values()).find(
      (shipment) => shipment.trackingNumber === trackingNumber
    );
  }

  async createShipment(shipment: InsertShipment): Promise<Shipment> {
    const id = this.shipmentCurrentId++;
    const newShipment: Shipment = {
      ...shipment,
      id,
      trackingNumber: shipment.trackingNumber || null,
      trackingUrl: shipment.trackingUrl || null,
      carrier: shipment.carrier || null,
      shippingMethod: shipment.shippingMethod || null,
      shippingCost: shipment.shippingCost || null,
      status: shipment.status || "pending",
      labelUrl: shipment.labelUrl || null,
      packageWeight: shipment.packageWeight || null,
      dimensions: shipment.dimensions || null,
      shippedDate: shipment.shippedDate || null,
      estimatedDeliveryDate: shipment.estimatedDeliveryDate || null,
      deliveredDate: shipment.deliveredDate || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.shipments.set(id, newShipment);

    // Update order status to 'shipped' when a shipment is created
    const order = this.orders.get(shipment.orderId);
    if (order && order.status === 'pending') {
      this.updateOrderStatus(order.id, 'shipped');
    }

    return newShipment;
  }

  async updateShipment(id: number, updates: Partial<Shipment>): Promise<Shipment | undefined> {
    const shipment = this.shipments.get(id);
    if (!shipment) return undefined;
    
    const updatedShipment = { 
      ...shipment, 
      ...updates,
      updatedAt: new Date().toISOString() 
    };
    this.shipments.set(id, updatedShipment);
    
    // If status is updated to 'delivered', update the order status too
    if (updates.status === 'delivered' && shipment.status !== 'delivered') {
      const order = this.orders.get(shipment.orderId);
      if (order) {
        this.updateOrderStatus(order.id, 'delivered');
      }
    }
    
    return updatedShipment;
  }
  
  // Shipping Provider methods
  async getAllShippingProviders(): Promise<ShippingProvider[]> {
    return Array.from(this.shippingProviders.values());
  }

  async getShippingProviderById(id: number): Promise<ShippingProvider | undefined> {
    return this.shippingProviders.get(id);
  }

  async getShippingProviderByName(name: string): Promise<ShippingProvider | undefined> {
    return Array.from(this.shippingProviders.values()).find(
      (provider) => provider.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createShippingProvider(provider: InsertShippingProvider): Promise<ShippingProvider> {
    const id = this.shippingProviderCurrentId++;
    const newProvider: ShippingProvider = {
      ...provider,
      id,
      apiKey: provider.apiKey || null,
      apiSecret: provider.apiSecret || null,
      active: provider.active ?? true,
      settings: provider.settings || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.shippingProviders.set(id, newProvider);
    return newProvider;
  }

  async updateShippingProvider(id: number, updates: Partial<ShippingProvider>): Promise<ShippingProvider | undefined> {
    const provider = this.shippingProviders.get(id);
    if (!provider) return undefined;
    
    const updatedProvider = { 
      ...provider, 
      ...updates,
      updatedAt: new Date().toISOString() 
    };
    this.shippingProviders.set(id, updatedProvider);
    return updatedProvider;
  }

  async toggleShippingProviderStatus(id: number, active: boolean): Promise<ShippingProvider | undefined> {
    const provider = this.shippingProviders.get(id);
    if (!provider) return undefined;
    
    const updatedProvider = { 
      ...provider, 
      active,
      updatedAt: new Date().toISOString() 
    };
    this.shippingProviders.set(id, updatedProvider);
    return updatedProvider;
  }

  // Inventory methods
  async getUserInventoryItems(userId: number): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItems.values()).filter(
      (item) => item.userId === userId
    );
  }

  async getInventoryItemById(id: number): Promise<InventoryItem | undefined> {
    return this.inventoryItems.get(id);
  }

  async getInventoryItemBySku(userId: number, sku: string): Promise<InventoryItem | undefined> {
    return Array.from(this.inventoryItems.values()).find(
      (item) => item.userId === userId && item.sku === sku
    );
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.inventoryItemCurrentId++;
    const newItem: InventoryItem = {
      id,
      userId: item.userId,
      name: item.name,
      description: item.description || null,
      category: item.category || null,
      price: item.price,
      sku: item.sku,
      quantity: item.quantity,
      lowStockThreshold: item.lowStockThreshold || 10,
      imageUrls: item.imageUrls || null,
      imageUrl: item.imageUrl || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.inventoryItems.set(id, newItem);
    return newItem;
  }

  async updateInventoryItem(id: number, updates: Partial<InventoryItem>): Promise<InventoryItem | undefined> {
    const item = this.inventoryItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { 
      ...item, 
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async updateInventoryQuantity(id: number, quantityChange: number): Promise<InventoryItem | undefined> {
    const item = this.inventoryItems.get(id);
    if (!item) return undefined;
    
    const newQuantity = Math.max(0, item.quantity + quantityChange);
    const updatedItem = { 
      ...item, 
      quantity: newQuantity,
      updatedAt: new Date().toISOString()
    };
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventoryItems.delete(id);
  }

  // External Integration: Social Media Connections
  async getSocialConnections(userId: number): Promise<SocialConnection[]> {
    return Array.from(this.socialConnections.values()).filter(
      (connection) => connection.userId === userId
    );
  }

  async getSocialConnectionByPlatform(userId: number, platform: string): Promise<SocialConnection | undefined> {
    return Array.from(this.socialConnections.values()).find(
      (connection) => connection.userId === userId && connection.platform === platform
    );
  }

  async createSocialConnection(connection: InsertSocialConnection): Promise<SocialConnection> {
    const id = this.socialConnectionCurrentId++;
    const newConnection: SocialConnection = {
      ...connection,
      id,
      isConnected: connection.isConnected ?? true,
      lastSynced: new Date().toISOString(),
      metadata: connection.metadata ?? {}
    };
    this.socialConnections.set(id, newConnection);
    return newConnection;
  }

  async updateSocialConnection(id: number, updates: Partial<SocialConnection>): Promise<SocialConnection | undefined> {
    const connection = this.socialConnections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { ...connection, ...updates };
    this.socialConnections.set(id, updatedConnection);
    return updatedConnection;
  }

  // External Integration: E-commerce Connections
  async getEcommerceConnections(userId: number): Promise<EcommerceConnection[]> {
    return Array.from(this.ecommerceConnections.values()).filter(
      (connection) => connection.userId === userId
    );
  }

  async getEcommerceConnectionByPlatform(userId: number, platform: string): Promise<EcommerceConnection | undefined> {
    return Array.from(this.ecommerceConnections.values()).find(
      (connection) => connection.userId === userId && connection.platform === platform
    );
  }

  async createEcommerceConnection(connection: InsertEcommerceConnection): Promise<EcommerceConnection> {
    const id = this.ecommerceConnectionCurrentId++;
    const newConnection: EcommerceConnection = {
      ...connection,
      id,
      isConnected: connection.isConnected ?? true,
      lastSynced: new Date().toISOString(),
      metadata: connection.metadata ?? {}
    };
    this.ecommerceConnections.set(id, newConnection);
    return newConnection;
  }

  async updateEcommerceConnection(id: number, updates: Partial<EcommerceConnection>): Promise<EcommerceConnection | undefined> {
    const connection = this.ecommerceConnections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { ...connection, ...updates };
    this.ecommerceConnections.set(id, updatedConnection);
    return updatedConnection;
  }

  // External Integration: Website Tracking
  async getTrackedWebsites(userId: number): Promise<TrackedWebsite[]> {
    return Array.from(this.trackedWebsites.values()).filter(
      (website) => website.userId === userId
    );
  }

  async getTrackedWebsiteById(id: number): Promise<TrackedWebsite | undefined> {
    return this.trackedWebsites.get(id);
  }

  async getTrackedWebsiteByTrackingId(trackingId: string): Promise<TrackedWebsite | undefined> {
    return Array.from(this.trackedWebsites.values()).find(
      (website) => website.trackingId === trackingId
    );
  }
  
  async getTrackedWebsiteByDomain(userId: number, domain: string): Promise<TrackedWebsite | undefined> {
    return Array.from(this.trackedWebsites.values()).find(
      (website) => website.userId === userId && website.domain === domain
    );
  }

  async createTrackedWebsite(website: InsertTrackedWebsite): Promise<TrackedWebsite> {
    const id = this.trackedWebsiteCurrentId++;
    const newWebsite: TrackedWebsite = {
      ...website,
      id,
      createdAt: new Date().toISOString(),
      isActive: website.isActive ?? true
    };
    this.trackedWebsites.set(id, newWebsite);
    return newWebsite;
  }

  // External Integration: Analytics Data
  async recordPageView(pageView: InsertPageView): Promise<PageView> {
    const id = this.pageViewCurrentId++;
    const newPageView: PageView = {
      ...pageView,
      id,
      timestamp: pageView.timestamp ? pageView.timestamp.toISOString() : new Date().toISOString()
    };
    this.pageViews.set(id, newPageView);
    return newPageView;
  }

  async recordEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventCurrentId++;
    const newEvent: Event = {
      ...event,
      id,
      timestamp: event.timestamp ? event.timestamp.toISOString() : new Date().toISOString()
    };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async getPageViewsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<PageView[]> {
    const startDateString = startDate.toISOString();
    const endDateString = endDate.toISOString();
    
    return Array.from(this.pageViews.values()).filter(
      (pageView) => {
        if (pageView.websiteId !== websiteId) return false;
        
        // Convert stored timestamps to Date objects for comparison
        const timestamp = new Date(pageView.timestamp).toISOString();
        return timestamp >= startDateString && timestamp <= endDateString;
      }
    );
  }

  async getEventsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<Event[]> {
    const startDateString = startDate.toISOString();
    const endDateString = endDate.toISOString();
    
    return Array.from(this.events.values()).filter(
      (event) => {
        if (event.websiteId !== websiteId) return false;
        
        // Convert stored timestamps to Date objects for comparison
        const timestamp = new Date(event.timestamp).toISOString();
        return timestamp >= startDateString && timestamp <= endDateString;
      }
    );
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from './database-storage';

// Note: Switch between MemStorage and DatabaseStorage as needed
// For real external integrations, use DatabaseStorage
// export const storage = new MemStorage();
export const storage = new DatabaseStorage();
