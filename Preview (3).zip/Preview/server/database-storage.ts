import { 
  users, appointments, availableSlots, contacts, events, inventoryItems, 
  notifications, orderItems, orders, pageViews, products, shipments, shippingProviders, 
  socialConnections, socialMediaAccounts, ecommerceConnections, trackedWebsites, 
  websiteAnalytics,
  type User, type InsertUser, type Contact, type InsertContact,
  type Appointment, type InsertAppointment, type AvailableSlot, type InsertAvailableSlot,
  type WebsiteAnalytics, type InsertWebsiteAnalytics, type SocialMediaAccount, type InsertSocialMediaAccount,
  type Notification, type InsertNotification, type Product, type InsertProduct,
  type Order, type InsertOrder, type OrderItem, type InsertOrderItem,
  type Shipment, type InsertShipment, type ShippingProvider, type InsertShippingProvider,
  type InventoryItem, type InsertInventoryItem, type SocialConnection, type InsertSocialConnection,
  type EcommerceConnection, type InsertEcommerceConnection, type TrackedWebsite, type InsertTrackedWebsite,
  type PageView, type InsertPageView, type Event, type InsertEvent
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, and, between, desc } from "drizzle-orm";
import { nanoid } from "nanoid";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: 'session' 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserProfile(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateStripeCustomerId(userId: number, stripeCustomerId: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserStripeInfo(
    userId: number, 
    stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }
  ): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId: stripeInfo.stripeCustomerId,
        stripeSubscriptionId: stripeInfo.stripeSubscriptionId
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Contact methods
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const [contact] = await db.insert(contacts).values(insertContact).returning();
    return contact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return await db.select().from(contacts).orderBy(desc(contacts.createdAt));
  }

  // Appointment methods
  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [createdAppointment] = await db.insert(appointments).values(appointment).returning();
    return createdAppointment;
  }

  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appointment;
  }

  async getAppointmentsByEmail(email: string): Promise<Appointment[]> {
    return await db.select().from(appointments).where(eq(appointments.email, email));
  }

  async getAllAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments).orderBy(desc(appointments.createdAt));
  }

  async updateAppointmentStatus(id: number, status: string): Promise<Appointment | undefined> {
    const [appointment] = await db
      .update(appointments)
      .set({ status })
      .where(eq(appointments.id, id))
      .returning();
    return appointment;
  }

  // Available slots methods
  async getAvailableSlotsByDate(date: string): Promise<AvailableSlot[]> {
    return await db
      .select()
      .from(availableSlots)
      .where(eq(availableSlots.date, date));
  }

  async createAvailableSlot(slot: InsertAvailableSlot): Promise<AvailableSlot> {
    const [createdSlot] = await db.insert(availableSlots).values(slot).returning();
    return createdSlot;
  }

  async updateSlotAvailability(id: number, isAvailable: boolean): Promise<AvailableSlot | undefined> {
    const [slot] = await db
      .update(availableSlots)
      .set({ isAvailable })
      .where(eq(availableSlots.id, id))
      .returning();
    return slot;
  }

  async bulkCreateDefaultSlots(date: string, timeSlots: string[]): Promise<AvailableSlot[]> {
    const slotsToInsert = timeSlots.map(timeSlot => ({
      date,
      timeSlot,
      isAvailable: true,
      createdAt: new Date().toISOString()
    }));

    return await db.insert(availableSlots).values(slotsToInsert).returning();
  }

  // Website Analytics methods
  async getWebsiteAnalytics(userId: number): Promise<WebsiteAnalytics | undefined> {
    const [analytics] = await db
      .select()
      .from(websiteAnalytics)
      .where(eq(websiteAnalytics.userId, userId));
    return analytics;
  }

  async createWebsiteAnalytics(analytics: InsertWebsiteAnalytics): Promise<WebsiteAnalytics> {
    const [createdAnalytics] = await db.insert(websiteAnalytics).values(analytics).returning();
    return createdAnalytics;
  }

  async updateWebsiteAnalytics(id: number, updates: Partial<WebsiteAnalytics>): Promise<WebsiteAnalytics | undefined> {
    const [analytics] = await db
      .update(websiteAnalytics)
      .set({ ...updates, lastUpdated: new Date().toISOString() })
      .where(eq(websiteAnalytics.id, id))
      .returning();
    return analytics;
  }

  // Social Media Account methods
  async getSocialMediaAccounts(userId: number): Promise<SocialMediaAccount[]> {
    return await db
      .select()
      .from(socialMediaAccounts)
      .where(eq(socialMediaAccounts.userId, userId));
  }

  async getSocialMediaAccountById(id: number): Promise<SocialMediaAccount | undefined> {
    const [account] = await db
      .select()
      .from(socialMediaAccounts)
      .where(eq(socialMediaAccounts.id, id));
    return account;
  }

  async getSocialMediaAccountByPlatform(userId: number, platform: string): Promise<SocialMediaAccount | undefined> {
    const [account] = await db
      .select()
      .from(socialMediaAccounts)
      .where(and(
        eq(socialMediaAccounts.userId, userId),
        eq(socialMediaAccounts.platform, platform)
      ));
    return account;
  }

  async createSocialMediaAccount(account: InsertSocialMediaAccount): Promise<SocialMediaAccount> {
    const [createdAccount] = await db.insert(socialMediaAccounts).values(account).returning();
    return createdAccount;
  }

  async updateSocialMediaAccount(id: number, updates: Partial<SocialMediaAccount>): Promise<SocialMediaAccount | undefined> {
    const [account] = await db
      .update(socialMediaAccounts)
      .set(updates)
      .where(eq(socialMediaAccounts.id, id))
      .returning();
    return account;
  }

  // Notification methods
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [createdNotification] = await db.insert(notifications).values({
      ...notification,
      isRead: false,
      createdAt: new Date().toISOString()
    }).returning();
    return createdNotification;
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return notification;
  }

  async deleteNotification(id: number): Promise<boolean> {
    const result = await db
      .delete(notifications)
      .where(eq(notifications.id, id))
      .returning({ id: notifications.id });
    return result.length > 0;
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [createdProduct] = await db.insert(products).values(product).returning();
    return createdProduct;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const [product] = await db
      .update(products)
      .set({ ...updates, updatedAt: new Date().toISOString() })
      .where(eq(products.id, id))
      .returning();
    return product;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db
      .delete(products)
      .where(eq(products.id, id))
      .returning({ id: products.id });
    return result.length > 0;
  }

  // Order methods
  async getAllOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getUserOrders(userId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber));
    return order;
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const orderToCreate = {
      ...order,
      orderNumber: order.orderNumber || `ORD-${nanoid(8).toUpperCase()}`,
      orderDate: order.orderDate || new Date().toISOString(),
      status: order.status || "pending",
      paymentStatus: order.paymentStatus || "paid"
    };

    const [createdOrder] = await db.insert(orders).values(orderToCreate).returning();
    return createdOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ 
        status, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  // Order Item methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const [createdOrderItem] = await db.insert(orderItems).values(orderItem).returning();
    return createdOrderItem;
  }

  // Shipment methods
  async getShipmentsByOrder(orderId: number): Promise<Shipment[]> {
    return await db
      .select()
      .from(shipments)
      .where(eq(shipments.orderId, orderId));
  }

  async getShipmentById(id: number): Promise<Shipment | undefined> {
    const [shipment] = await db.select().from(shipments).where(eq(shipments.id, id));
    return shipment;
  }

  async getShipmentByTrackingNumber(trackingNumber: string): Promise<Shipment | undefined> {
    const [shipment] = await db
      .select()
      .from(shipments)
      .where(eq(shipments.trackingNumber, trackingNumber));
    return shipment;
  }

  async createShipment(shipment: InsertShipment): Promise<Shipment> {
    const [createdShipment] = await db.insert(shipments).values(shipment).returning();
    return createdShipment;
  }

  async updateShipment(id: number, updates: Partial<Shipment>): Promise<Shipment | undefined> {
    const [shipment] = await db
      .update(shipments)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(shipments.id, id))
      .returning();
    return shipment;
  }

  // Shipping Provider methods
  async getAllShippingProviders(): Promise<ShippingProvider[]> {
    return await db.select().from(shippingProviders);
  }

  async getShippingProviderById(id: number): Promise<ShippingProvider | undefined> {
    const [provider] = await db
      .select()
      .from(shippingProviders)
      .where(eq(shippingProviders.id, id));
    return provider;
  }

  async getShippingProviderByName(name: string): Promise<ShippingProvider | undefined> {
    const [provider] = await db
      .select()
      .from(shippingProviders)
      .where(eq(shippingProviders.name, name));
    return provider;
  }

  async createShippingProvider(provider: InsertShippingProvider): Promise<ShippingProvider> {
    const [createdProvider] = await db.insert(shippingProviders).values(provider).returning();
    return createdProvider;
  }

  async updateShippingProvider(id: number, updates: Partial<ShippingProvider>): Promise<ShippingProvider | undefined> {
    const [provider] = await db
      .update(shippingProviders)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(shippingProviders.id, id))
      .returning();
    return provider;
  }

  async toggleShippingProviderStatus(id: number, active: boolean): Promise<ShippingProvider | undefined> {
    const [provider] = await db
      .update(shippingProviders)
      .set({ 
        active, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(shippingProviders.id, id))
      .returning();
    return provider;
  }

  // Inventory methods
  async getUserInventoryItems(userId: number): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventoryItems)
      .where(eq(inventoryItems.userId, userId));
  }

  async getInventoryItemById(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db
      .select()
      .from(inventoryItems)
      .where(eq(inventoryItems.id, id));
    return item;
  }

  async getInventoryItemBySku(userId: number, sku: string): Promise<InventoryItem | undefined> {
    const [item] = await db
      .select()
      .from(inventoryItems)
      .where(and(
        eq(inventoryItems.userId, userId),
        eq(inventoryItems.sku, sku)
      ));
    return item;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [createdItem] = await db.insert(inventoryItems).values(item).returning();
    return createdItem;
  }

  async updateInventoryItem(id: number, updates: Partial<InventoryItem>): Promise<InventoryItem | undefined> {
    const [item] = await db
      .update(inventoryItems)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(inventoryItems.id, id))
      .returning();
    return item;
  }

  async updateInventoryQuantity(id: number, quantityChange: number): Promise<InventoryItem | undefined> {
    // First get the current quantity
    const item = await this.getInventoryItemById(id);
    if (!item) return undefined;
    
    // Calculate the new quantity
    const newQuantity = item.quantity + quantityChange;
    
    // Update the item with the new quantity
    return await this.updateInventoryItem(id, { quantity: newQuantity });
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db
      .delete(inventoryItems)
      .where(eq(inventoryItems.id, id))
      .returning({ id: inventoryItems.id });
    return result.length > 0;
  }

  // Social Media Connections (OAuth)
  async getSocialConnections(userId: number): Promise<SocialConnection[]> {
    return await db
      .select()
      .from(socialConnections)
      .where(eq(socialConnections.userId, userId));
  }

  async getSocialConnectionByPlatform(userId: number, platform: string): Promise<SocialConnection | undefined> {
    const [connection] = await db
      .select()
      .from(socialConnections)
      .where(and(
        eq(socialConnections.userId, userId),
        eq(socialConnections.platform, platform)
      ));
    return connection;
  }

  async createSocialConnection(connection: InsertSocialConnection): Promise<SocialConnection> {
    // Add defaults if not provided
    const socialConnectionToCreate = {
      ...connection,
      status: connection.status || "active",
      lastSynced: connection.lastSynced || new Date().toISOString(),
      metadata: connection.metadata || JSON.stringify({}),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const [createdConnection] = await db.insert(socialConnections).values(socialConnectionToCreate).returning();
    return createdConnection;
  }

  async updateSocialConnection(id: number, updates: Partial<SocialConnection>): Promise<SocialConnection | undefined> {
    const [connection] = await db
      .update(socialConnections)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(socialConnections.id, id))
      .returning();
    return connection;
  }

  // E-commerce Connections
  async getEcommerceConnections(userId: number): Promise<EcommerceConnection[]> {
    return await db
      .select()
      .from(ecommerceConnections)
      .where(eq(ecommerceConnections.userId, userId));
  }

  async getEcommerceConnectionByPlatform(userId: number, platform: string): Promise<EcommerceConnection | undefined> {
    const [connection] = await db
      .select()
      .from(ecommerceConnections)
      .where(and(
        eq(ecommerceConnections.userId, userId),
        eq(ecommerceConnections.platform, platform)
      ));
    return connection;
  }

  async createEcommerceConnection(connection: InsertEcommerceConnection): Promise<EcommerceConnection> {
    // Add defaults if not provided
    const ecommerceConnectionToCreate = {
      ...connection,
      status: connection.status || "active",
      lastSynced: connection.lastSynced || new Date().toISOString(),
      syncFrequency: connection.syncFrequency || "daily",
      metadata: connection.metadata || JSON.stringify({}),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const [createdConnection] = await db.insert(ecommerceConnections).values(ecommerceConnectionToCreate).returning();
    return createdConnection;
  }

  async updateEcommerceConnection(id: number, updates: Partial<EcommerceConnection>): Promise<EcommerceConnection | undefined> {
    const [connection] = await db
      .update(ecommerceConnections)
      .set({ 
        ...updates, 
        updatedAt: new Date().toISOString() 
      })
      .where(eq(ecommerceConnections.id, id))
      .returning();
    return connection;
  }

  // Website Tracking
  async getTrackedWebsites(userId: number): Promise<TrackedWebsite[]> {
    return await db
      .select()
      .from(trackedWebsites)
      .where(eq(trackedWebsites.userId, userId));
  }

  async getTrackedWebsiteById(id: number): Promise<TrackedWebsite | undefined> {
    const [website] = await db
      .select()
      .from(trackedWebsites)
      .where(eq(trackedWebsites.id, id));
    return website;
  }

  async getTrackedWebsiteByTrackingId(trackingId: string): Promise<TrackedWebsite | undefined> {
    const [website] = await db
      .select()
      .from(trackedWebsites)
      .where(eq(trackedWebsites.trackingId, trackingId));
    return website;
  }
  
  async getTrackedWebsiteByDomain(userId: number, domain: string): Promise<TrackedWebsite | undefined> {
    const [website] = await db
      .select()
      .from(trackedWebsites)
      .where(and(
        eq(trackedWebsites.userId, userId),
        eq(trackedWebsites.domain, domain)
      ));
    return website;
  }

  async createTrackedWebsite(website: InsertTrackedWebsite): Promise<TrackedWebsite> {
    // Generate a unique tracking ID if not provided
    const websiteToCreate = {
      ...website,
      trackingId: website.trackingId || `tr_${nanoid(16)}`,
      name: website.name || null,
      status: website.status || "active",
      settings: website.settings || JSON.stringify({
        trackPageViews: true,
        trackClicks: true,
        trackForms: true,
        trackErrors: true
      }),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const [createdWebsite] = await db.insert(trackedWebsites).values(websiteToCreate).returning();
    return createdWebsite;
  }

  // Analytics Data Recording
  async recordPageView(pageView: InsertPageView): Promise<PageView> {
    // Ensure required fields are set
    const pageViewToCreate = {
      ...pageView,
      timestamp: pageView.timestamp || new Date().toISOString(),
      title: pageView.title || null,
      visitorId: pageView.visitorId || null,
      sessionId: pageView.sessionId || null,
      referrer: pageView.referrer || null,
      userAgent: pageView.userAgent || null,
      deviceType: pageView.deviceType || null,
      deviceBrand: pageView.deviceBrand || null,
      browserName: pageView.browserName || null,
      browserVersion: pageView.browserVersion || null,
      osName: pageView.osName || null,
      osVersion: pageView.osVersion || null,
      countryCode: pageView.countryCode || null,
      city: pageView.city || null,
      region: pageView.region || null,
      longitude: pageView.longitude || null,
      latitude: pageView.latitude || null,
      exitPage: pageView.exitPage || false
    };
    
    const [createdPageView] = await db.insert(pageViews).values(pageViewToCreate).returning();
    return createdPageView;
  }

  async recordEvent(event: InsertEvent): Promise<Event> {
    // Ensure required fields are set
    const eventToCreate = {
      ...event,
      timestamp: event.timestamp || new Date().toISOString(),
      visitorId: event.visitorId || null,
      sessionId: event.sessionId || null,
      eventCategory: event.eventCategory || null,
      eventAction: event.eventAction || null,
      eventLabel: event.eventLabel || null,
      eventValue: event.eventValue || null,
      elementId: event.elementId || null,
      elementClasses: event.elementClasses || null,
      elementText: event.elementText || null,
      formData: event.formData || null
    };
    
    const [createdEvent] = await db.insert(events).values(eventToCreate).returning();
    return createdEvent;
  }

  async getPageViewsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<PageView[]> {
    return await db
      .select()
      .from(pageViews)
      .where(and(
        eq(pageViews.websiteId, websiteId),
        between(
          pageViews.timestamp, 
          startDate.toISOString(), 
          endDate.toISOString()
        )
      ))
      .orderBy(desc(pageViews.timestamp));
  }

  async getEventsByWebsite(websiteId: number, startDate: Date, endDate: Date): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .where(and(
        eq(events.websiteId, websiteId),
        between(
          events.timestamp, 
          startDate.toISOString(), 
          endDate.toISOString()
        )
      ))
      .orderBy(desc(events.timestamp));
  }
}