// Inventory Management API Routes
import { Request, Response } from "express";
import { InventoryItem } from "@shared/schema";

export function addInventoryRoutes(app: any, storage: any) {
  
  // Get all inventory items for user
  app.get("/api/inventory", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const inventoryItems = await storage.getUserInventoryItems(userId);
      res.json(inventoryItems);
    } catch (error) {
      console.error("Error fetching inventory items:", error);
      res.status(500).json({ message: "Failed to fetch inventory items" });
    }
  });
  
  // Get inventory item by ID
  app.get("/api/inventory/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const itemId = parseInt(req.params.id);
      const item = await storage.getInventoryItemById(itemId);
      
      if (!item) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      // Check if user has permission to access this item
      if (item.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "You don't have permission to access this item" });
      }
      
      res.json(item);
    } catch (error) {
      console.error(`Error fetching inventory item:`, error);
      res.status(500).json({ message: "Failed to fetch inventory item" });
    }
  });
  
  // Create new inventory item
  app.post("/api/inventory", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const itemData = {
        ...req.body,
        userId
      };
      
      // Create the item
      const newItem = await storage.createInventoryItem(itemData);
      
      res.status(201).json(newItem);
    } catch (error) {
      console.error("Error creating inventory item:", error);
      res.status(500).json({ message: "Failed to create inventory item" });
    }
  });
  
  // Update inventory item
  app.patch("/api/inventory/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const itemId = parseInt(req.params.id);
      const updates = req.body;
      
      // Get the current item to check permissions
      const currentItem = await storage.getInventoryItemById(itemId);
      
      if (!currentItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      // Check if user owns this item
      if (currentItem.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "You don't have permission to update this item" });
      }
      
      const updatedItem = await storage.updateInventoryItem(itemId, updates);
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating inventory item:", error);
      res.status(500).json({ message: "Failed to update inventory item" });
    }
  });
  
  // Update inventory quantity specifically
  app.patch("/api/inventory/:id/quantity", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const itemId = parseInt(req.params.id);
      const { quantity, adjustment } = req.body;
      
      // Get the current item to check permissions
      const currentItem = await storage.getInventoryItemById(itemId);
      
      if (!currentItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      // Check if user owns this item
      if (currentItem.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "You don't have permission to update this item" });
      }
      
      let updatedItem;
      
      if (adjustment) {
        // If adjustment is provided, adjust the current quantity
        updatedItem = await storage.updateInventoryQuantity(itemId, adjustment);
      } else if (quantity !== undefined) {
        // If quantity is provided, set to specific value
        updatedItem = await storage.updateInventoryItem(itemId, { quantity });
      } else {
        return res.status(400).json({ message: "Either quantity or adjustment must be provided" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating inventory quantity:", error);
      res.status(500).json({ message: "Failed to update inventory quantity" });
    }
  });
  
  // Delete inventory item
  app.delete("/api/inventory/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const itemId = parseInt(req.params.id);
      
      // Get the current item to check permissions
      const currentItem = await storage.getInventoryItemById(itemId);
      
      if (!currentItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      // Check if user owns this item
      if (currentItem.userId !== (req.user as any).id) {
        return res.status(403).json({ message: "You don't have permission to delete this item" });
      }
      
      const success = await storage.deleteInventoryItem(itemId);
      
      if (success) {
        res.status(200).json({ message: "Inventory item deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete inventory item" });
      }
    } catch (error) {
      console.error("Error deleting inventory item:", error);
      res.status(500).json({ message: "Failed to delete inventory item" });
    }
  });
  
  // Sync inventory with e-commerce platforms
  app.post("/api/inventory/sync", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const { platformId } = req.body;
      
      // In a real implementation, this would connect to the respective
      // e-commerce platform API and pull inventory data to sync with
      // our local inventory management system
      
      // For demonstration, we'll just return a success message
      res.json({ 
        success: true, 
        message: "Inventory sync completed successfully", 
        syncedItems: 42,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error("Error syncing inventory:", error);
      res.status(500).json({ message: "Failed to sync inventory" });
    }
  });
  
  // Get low stock items
  app.get("/api/inventory/alerts/low-stock", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const inventoryItems = await storage.getUserInventoryItems(userId);
      
      // Filter to find low stock items
      const lowStockItems = inventoryItems.filter(item => {
        // If a low stock threshold is defined, use it, otherwise default to 10
        const threshold = item.lowStockThreshold ?? 10;
        return item.quantity <= threshold;
      });
      
      res.json(lowStockItems);
    } catch (error) {
      console.error("Error fetching low stock items:", error);
      res.status(500).json({ message: "Failed to fetch low stock items" });
    }
  });
}