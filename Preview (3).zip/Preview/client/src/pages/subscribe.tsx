import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface SubscribeFormProps {
  planName: string;
  price: number;
  interval: string;
}

const SubscribeForm = ({ planName, price, interval }: SubscribeFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/payment-success',
        },
      });

      if (error) {
        toast({
          title: "Subscription Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Subscription Processing",
          description: "You will be redirected to the success page.",
        });
      }
    } catch (err) {
      console.error('Subscription error:', err);
      toast({
        title: "Subscription Error",
        description: "An unexpected error occurred during subscription processing.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit"
        disabled={!stripe || isProcessing} 
        className="w-full"
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Subscribe - $${price}/${interval}`
        )}
      </Button>
    </form>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [subscriptionDetails, setSubscriptionDetails] = useState<{
    planName: string;
    price: number;
    interval: string;
    priceId: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to subscribe to a plan.",
        variant: "destructive",
      });
      setLocation('/auth');
      return;
    }

    // Get plan details from URL parameters
    const params = new URLSearchParams(window.location.search);
    const planName = params.get('plan');
    const price = params.get('price');
    const interval = params.get('interval') || 'month';
    const priceId = params.get('priceId');

    if (!planName || !price || !priceId) {
      toast({
        title: "Missing information",
        description: "Subscription details are missing. Please select a plan first.",
        variant: "destructive",
      });
      setLocation('/packages');
      return;
    }

    const subscriptionPrice = parseFloat(price);
    setSubscriptionDetails({
      planName,
      price: subscriptionPrice,
      interval,
      priceId
    });

    // Create subscription as soon as the page loads
    apiRequest("POST", "/api/create-subscription", { 
      priceId,
      planName,
      interval
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Subscription setup error:', error);
        toast({
          title: "Subscription Setup Failed",
          description: "Could not initialize subscription. Please try again later.",
          variant: "destructive",
        });
        setIsLoading(false);
      });
  }, [toast, setLocation, user]);

  if (isLoading || !subscriptionDetails) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="container max-w-md mx-auto py-12">
        <Card>
          <CardHeader>
            <CardTitle>Subscription Failed</CardTitle>
            <CardDescription>
              We couldn't initialize the subscription process. Please try again later.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setLocation('/packages')} className="w-full">
              Return to Packages
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-md mx-auto py-12">
      <Card>
        <CardHeader>
          <CardTitle>Subscribe to {subscriptionDetails.planName}</CardTitle>
          <CardDescription>
            You're subscribing to {subscriptionDetails.planName} for ${subscriptionDetails.price}/{subscriptionDetails.interval}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <SubscribeForm 
              planName={subscriptionDetails.planName}
              price={subscriptionDetails.price}
              interval={subscriptionDetails.interval}
            />
          </Elements>
        </CardContent>
      </Card>
    </div>
  );
}