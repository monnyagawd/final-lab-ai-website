/**
 * Stripe webhook handler for the Lab AI platform
 * 
 * This module processes incoming webhook events from Stripe
 * and performs the appropriate actions based on the event type.
 */

import { Request, Response } from 'express';
import Stripe from 'stripe';
import { verifyWebhookEvent } from './stripe';
import { storage } from './storage';
import { nanoid } from 'nanoid';

// Map to keep track of processed events to prevent duplicate processing
const processedEvents = new Map<string, boolean>();

/**
 * Process a webhook event from Stripe
 * @param event The Stripe event object
 */
async function processWebhookEvent(event: Stripe.Event) {
  // Check if we've already processed this event
  if (processedEvents.get(event.id)) {
    console.log(`Event ${event.id} already processed, skipping`);
    return;
  }

  console.log(`Processing Stripe webhook event: ${event.type}`);

  try {
    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentIntentSucceeded(event.data.object as Stripe.PaymentIntent);
        break;
        
      case 'payment_intent.payment_failed':
        await handlePaymentIntentFailed(event.data.object as Stripe.PaymentIntent);
        break;
        
      case 'customer.subscription.created':
        await handleSubscriptionCreated(event.data.object as Stripe.Subscription);
        break;
        
      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object as Stripe.Subscription);
        break;
        
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
        break;
        
      case 'invoice.payment_succeeded':
        await handleInvoicePaymentSucceeded(event.data.object as Stripe.Invoice);
        break;
        
      case 'invoice.payment_failed':
        await handleInvoicePaymentFailed(event.data.object as Stripe.Invoice);
        break;
        
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }
    
    // Mark this event as processed
    processedEvents.set(event.id, true);
    
    // Limit the size of the processedEvents map (keep last 1000 events)
    if (processedEvents.size > 1000) {
      const keys = Array.from(processedEvents.keys());
      const oldestKeys = keys.slice(0, keys.length - 1000);
      oldestKeys.forEach(key => processedEvents.delete(key));
    }
  } catch (error: any) {
    console.error(`Error processing webhook event ${event.id} (${event.type}):`, error);
    throw error; // Re-throw to trigger a retry
  }
}

/**
 * Handle a successful payment intent
 * @param paymentIntent The payment intent object
 */
async function handlePaymentIntentSucceeded(paymentIntent: Stripe.PaymentIntent) {
  console.log(`Payment intent succeeded: ${paymentIntent.id}`);
  
  // Extract metadata from the payment intent
  const { userId, packageName } = paymentIntent.metadata || {};
  
  if (userId) {
    // Find the user
    const user = await storage.getUser(parseInt(userId));
    
    if (!user) {
      console.error(`User not found for payment intent ${paymentIntent.id} (userId: ${userId})`);
      return;
    }
    
    // Create a new notification for the user
    await storage.createNotification({
      userId: parseInt(userId),
      type: 'payment_success',
      title: 'Payment Successful',
      message: `Your payment of $${(paymentIntent.amount / 100).toFixed(2)} for ${packageName || 'Website Package'} was successful.`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
    
    // Create an order record
    const orderNumber = `ORD-${nanoid(8)}`;
    
    await storage.createOrder({
      userId: parseInt(userId),
      orderNumber,
      status: 'completed',
      total: paymentIntent.amount / 100,
      paymentMethod: 'credit_card',
      paymentId: paymentIntent.id,
      customerName: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
      customerEmail: user.email,
      orderDate: new Date().toISOString(),
      metadata: JSON.stringify({
        packageName: packageName || 'Website Package',
        paymentIntentId: paymentIntent.id
      })
    });
  }
}

/**
 * Handle a failed payment intent
 * @param paymentIntent The payment intent object
 */
async function handlePaymentIntentFailed(paymentIntent: Stripe.PaymentIntent) {
  console.log(`Payment intent failed: ${paymentIntent.id}`);
  
  // Extract metadata from the payment intent
  const { userId, packageName } = paymentIntent.metadata || {};
  
  if (userId) {
    // Create a new notification for the user
    await storage.createNotification({
      userId: parseInt(userId),
      type: 'payment_failed',
      title: 'Payment Failed',
      message: `Your payment of $${(paymentIntent.amount / 100).toFixed(2)} for ${packageName || 'Website Package'} failed. Please check your payment details and try again.`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }
}

/**
 * Handle a subscription creation
 * @param subscription The subscription object
 */
async function handleSubscriptionCreated(subscription: Stripe.Subscription) {
  console.log(`Subscription created: ${subscription.id}`);
  
  // Extract metadata from the subscription
  const { userId, planName } = subscription.metadata || {};
  
  if (userId) {
    // Create a new notification for the user
    await storage.createNotification({
      userId: parseInt(userId),
      type: 'subscription_created',
      title: 'Subscription Started',
      message: `Your subscription to ${planName || 'Website Service'} has been activated.`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }
}

/**
 * Handle a subscription update
 * @param subscription The subscription object
 */
async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  console.log(`Subscription updated: ${subscription.id}`);
  
  // Extract metadata from the subscription
  const { userId, planName } = subscription.metadata || {};
  
  if (userId) {
    // Check if the subscription status has changed
    if (subscription.status === 'past_due') {
      // Create a new notification for the user
      await storage.createNotification({
        userId: parseInt(userId),
        type: 'subscription_past_due',
        title: 'Payment Past Due',
        message: `Your subscription payment for ${planName || 'Website Service'} is past due. Please update your payment information to avoid service interruption.`,
        isRead: false,
        createdAt: new Date().toISOString()
      });
    } else if (subscription.status === 'canceled') {
      // Create a new notification for the user
      await storage.createNotification({
        userId: parseInt(userId),
        type: 'subscription_canceled',
        title: 'Subscription Canceled',
        message: `Your subscription to ${planName || 'Website Service'} has been canceled.`,
        isRead: false,
        createdAt: new Date().toISOString()
      });
    }
  }
}

/**
 * Handle a subscription deletion
 * @param subscription The subscription object
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log(`Subscription deleted: ${subscription.id}`);
  
  // Extract metadata from the subscription
  const { userId, planName } = subscription.metadata || {};
  
  if (userId) {
    // Create a new notification for the user
    await storage.createNotification({
      userId: parseInt(userId),
      type: 'subscription_ended',
      title: 'Subscription Ended',
      message: `Your subscription to ${planName || 'Website Service'} has ended.`,
      isRead: false,
      createdAt: new Date().toISOString()
    });
    
    // Update the user's subscription ID
    await storage.updateUserStripeInfo(parseInt(userId), {
      customerId: subscription.customer as string,
      subscriptionId: null
    });
  }
}

/**
 * Handle a successful invoice payment
 * @param invoice The invoice object
 */
async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
  console.log(`Invoice payment succeeded: ${invoice.id}`);
  
  if (invoice.subscription && invoice.customer) {
    // Get the subscription
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);
    
    try {
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
      
      // Extract metadata from the subscription
      const { userId, planName } = subscription.metadata || {};
      
      if (userId) {
        // Create a new notification for the user
        await storage.createNotification({
          userId: parseInt(userId),
          type: 'invoice_paid',
          title: 'Invoice Paid',
          message: `Your payment of $${(invoice.amount_paid / 100).toFixed(2)} for ${planName || 'Website Service'} was successful.`,
          isRead: false,
          createdAt: new Date().toISOString()
        });
        
        // Create an order record
        const user = await storage.getUser(parseInt(userId));
        
        if (user) {
          const orderNumber = `ORD-${nanoid(8)}`;
          
          await storage.createOrder({
            userId: parseInt(userId),
            orderNumber,
            status: 'completed',
            total: invoice.amount_paid / 100,
            paymentMethod: 'credit_card',
            paymentId: invoice.id,
            customerName: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
            customerEmail: user.email,
            orderDate: new Date().toISOString(),
            metadata: JSON.stringify({
              planName: planName || 'Website Service',
              invoiceId: invoice.id,
              subscriptionId: subscription.id
            })
          });
        }
      }
    } catch (error) {
      console.error(`Error retrieving subscription ${invoice.subscription}:`, error);
    }
  }
}

/**
 * Handle a failed invoice payment
 * @param invoice The invoice object
 */
async function handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
  console.log(`Invoice payment failed: ${invoice.id}`);
  
  if (invoice.subscription && invoice.customer) {
    // Get the subscription
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);
    
    try {
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
      
      // Extract metadata from the subscription
      const { userId, planName } = subscription.metadata || {};
      
      if (userId) {
        // Create a new notification for the user
        await storage.createNotification({
          userId: parseInt(userId),
          type: 'invoice_failed',
          title: 'Payment Failed',
          message: `Your payment of $${(invoice.amount_due / 100).toFixed(2)} for ${planName || 'Website Service'} failed. Please update your payment information.`,
          isRead: false,
          createdAt: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error(`Error retrieving subscription ${invoice.subscription}:`, error);
    }
  }
}

/**
 * Webhook handler for Stripe events
 * @param req Express request object
 * @param res Express response object
 */
export async function stripeWebhookHandler(req: Request, res: Response) {
  const sig = req.headers['stripe-signature'];
  
  if (!sig) {
    return res.status(400).send('Missing stripe-signature header');
  }
  
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    console.warn('STRIPE_WEBHOOK_SECRET is not set, skipping signature verification');
    
    try {
      // Parse the event ourselves
      const event = req.body as Stripe.Event;
      
      // Process the event
      await processWebhookEvent(event);
      
      // Return a 200 response
      return res.status(200).send({ received: true });
    } catch (error) {
      console.error('Error processing webhook:', error);
      return res.status(400).send(`Webhook Error: ${error.message}`);
    }
  }
  
  // Verify the event
  try {
    const event = await verifyWebhookEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    
    // Process the event
    await processWebhookEvent(event);
    
    // Return a 200 response
    return res.status(200).send({ received: true });
  } catch (error: any) {
    console.error('Error verifying webhook:', error);
    return res.status(400).send(`Webhook Error: ${error.message}`);
  }
}