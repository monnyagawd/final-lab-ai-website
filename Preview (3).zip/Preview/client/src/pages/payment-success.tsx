import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, Loader2 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

export default function PaymentSuccess() {
  const [loading, setLoading] = useState(true);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paymentIntentId = params.get('payment_intent');
    const redirectStatus = params.get('redirect_status');

    if (!paymentIntentId || redirectStatus !== 'succeeded') {
      toast({
        title: 'Payment Error',
        description: 'Could not verify your payment. Please contact support.',
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    // Verify the payment with our backend
    apiRequest('GET', `/api/verify-payment?payment_intent=${paymentIntentId}`)
      .then((res) => res.json())
      .then((data) => {
        setPaymentDetails(data);
        setLoading(false);
        
        // Show success toast
        toast({
          title: 'Payment Successful!',
          description: 'Thank you for your purchase.',
        });
      })
      .catch((error) => {
        console.error('Payment verification error:', error);
        toast({
          title: 'Verification Error',
          description: 'Could not verify your payment. Please contact support.',
          variant: 'destructive',
        });
        setLoading(false);
      });
  }, [toast]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-lg font-medium">Verifying your payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-md mx-auto py-12">
      <Card>
        <CardHeader className="text-center">
          <div className="mx-auto my-4 bg-green-100 p-3 rounded-full w-16 h-16 flex items-center justify-center">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl">Payment Successful!</CardTitle>
          <CardDescription>
            Thank you for your purchase. Your payment has been processed successfully.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {paymentDetails && (
            <div className="space-y-4">
              <div className="border-t border-b py-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Package</span>
                  <span className="font-medium">{paymentDetails.packageName || 'Website Package'}</span>
                </div>
                
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-medium">${(paymentDetails.amount / 100).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-muted-foreground">Date</span>
                  <span className="font-medium">{new Date().toLocaleDateString()}</span>
                </div>
                
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-muted-foreground">Transaction ID</span>
                  <span className="font-medium text-xs">{paymentDetails.paymentIntentId}</span>
                </div>
              </div>
              
              <p className="text-center text-sm text-muted-foreground">
                A receipt has been sent to your email address.
              </p>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex-col space-y-2">
          <Button onClick={() => setLocation('/dashboard')} className="w-full">
            Go to Dashboard
          </Button>
          <Button onClick={() => setLocation('/')} variant="outline" className="w-full">
            Return Home
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}