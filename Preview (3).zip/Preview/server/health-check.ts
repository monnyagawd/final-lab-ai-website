/**
 * Health check middleware for Lab AI application
 * Provides functionality to check the health of various services
 */

import { Request, Response } from 'express';
import Stripe from 'stripe';
import { checkDatabaseConnection } from './db-checker';

// Function to check Stripe API connectivity
export async function checkStripeConnection(): Promise<boolean> {
  if (!process.env.STRIPE_SECRET_KEY) {
    return false;
  }
  
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    await stripe.balance.retrieve();
    return true;
  } catch (error) {
    console.error('Stripe health check failed:', error);
    return false;
  }
}

// Middleware for health check endpoint
export async function healthCheckHandler(req: Request, res: Response): Promise<void> {
  // Basic health information
  const healthStatus: {
    status: string;
    timestamp: string;
    uptime: number;
    environment: string;
    version: string;
    services: {
      database: boolean;
      stripe: boolean;
      [key: string]: boolean | undefined;
    };
  } = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: process.env.npm_package_version || '1.0.0',
    services: {
      database: true,
      stripe: Boolean(process.env.STRIPE_SECRET_KEY)
    }
  };
  
  // Check database connectivity if in production
  if (process.env.NODE_ENV === 'production') {
    healthStatus.services.database = await checkDatabaseConnection();
    
    // Only check Stripe if the key is configured
    if (process.env.STRIPE_SECRET_KEY) {
      healthStatus.services.stripe = await checkStripeConnection();
    }
  }
  
  // Determine overall status
  const servicesHealthy = Object.values(healthStatus.services).every(Boolean);
  healthStatus.status = servicesHealthy ? 'healthy' : 'degraded';
  
  // Set appropriate status code
  res.status(servicesHealthy ? 200 : 503).json(healthStatus);
}

// Function to check critical dependencies on application start
export async function startupHealthCheck(): Promise<boolean> {
  console.log('Performing startup health check...');
  
  // Check database connectivity
  const databaseHealthy = await checkDatabaseConnection();
  console.log(`Database connection: ${databaseHealthy ? 'OK' : 'FAILED'}`);
  
  // Check if Stripe is configured and working
  const stripeConfigured = Boolean(process.env.STRIPE_SECRET_KEY);
  console.log(`Stripe configuration: ${stripeConfigured ? 'OK' : 'NOT CONFIGURED'}`);
  
  let stripeHealthy = false;
  if (stripeConfigured) {
    stripeHealthy = await checkStripeConnection();
    console.log(`Stripe API connection: ${stripeHealthy ? 'OK' : 'FAILED'}`);
  }
  
  // Calculate overall health
  const isHealthy = databaseHealthy && (!stripeConfigured || stripeHealthy);
  
  if (isHealthy) {
    console.log('Startup health check: All critical services are available');
  } else {
    console.warn('Startup health check: Some critical services are unavailable');
  }
  
  return isHealthy;
}