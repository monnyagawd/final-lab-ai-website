import { Request, Response } from "express";
import { storage } from "./storage";
import { processAnalyticsData } from "./analytics-service";

// Get analytics data for a tracked website
export async function getWebsiteAnalytics(req: Request, res: Response) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  try {
    const websiteId = parseInt(req.params.id);
    const website = await storage.getTrackedWebsiteById(websiteId);
    
    if (!website) {
      return res.status(404).json({ message: "Website not found" });
    }
    
    // Verify the website belongs to the authenticated user
    if (website.userId !== req.user!.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    // Get query parameters for date range
    const start = req.query.start 
      ? new Date(req.query.start as string) 
      : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // Default to last 30 days
    
    const end = req.query.end 
      ? new Date(req.query.end as string) 
      : new Date();
    
    // Fetch real analytics data
    const pageViews = await storage.getPageViewsByWebsite(websiteId, start, end);
    const events = await storage.getEventsByWebsite(websiteId, start, end);
    
    // Log for debugging
    console.log(`Retrieved ${pageViews.length} page views and ${events.length} events for website ${websiteId}`);
    
    // Process the analytics data (real data or empty structure if none exists)
    const analyticsData = processAnalyticsData(pageViews, events);
    
    // Return the processed data
    return res.json(analyticsData);
  } catch (error) {
    console.error("Error getting website analytics:", error);
    res.status(500).json({ message: "Error retrieving analytics data" });
  }
}