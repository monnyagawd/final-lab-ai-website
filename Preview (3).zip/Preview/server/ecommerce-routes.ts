// E-commerce Integration API Routes
export function addEcommerceRoutes(app: any, storage: any) {
  
  // Get user's e-commerce connections
  app.get("/api/ecommerce/connections", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const connections = await storage.getEcommerceConnections(userId);
      res.json(connections);
    } catch (error) {
      console.error("Error fetching e-commerce connections:", error);
      res.status(500).json({ message: "Failed to fetch e-commerce connections" });
    }
  });
  
  // Create a new e-commerce connection
  app.post("/api/ecommerce/connections", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const connectionData = {
        ...req.body,
        userId
      };
      
      // Create the connection
      const newConnection = await storage.createEcommerceConnection(connectionData);
      
      res.status(201).json(newConnection);
    } catch (error) {
      console.error("Error creating e-commerce connection:", error);
      res.status(500).json({ message: "Failed to create e-commerce connection" });
    }
  });
  
  // Get e-commerce connection by platform
  app.get("/api/ecommerce/connections/:platform", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as any).id;
      const platform = req.params.platform;
      
      const connection = await storage.getEcommerceConnectionByPlatform(userId, platform);
      
      if (!connection) {
        return res.status(404).json({ message: `No ${platform} connection found` });
      }
      
      res.json(connection);
    } catch (error) {
      console.error(`Error fetching ${req.params.platform} connection:`, error);
      res.status(500).json({ message: `Failed to fetch ${req.params.platform} connection` });
    }
  });
  
  // Update an e-commerce connection
  app.patch("/api/ecommerce/connections/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const connectionId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedConnection = await storage.updateEcommerceConnection(connectionId, updates);
      
      if (!updatedConnection) {
        return res.status(404).json({ message: "Connection not found" });
      }
      
      res.json(updatedConnection);
    } catch (error) {
      console.error("Error updating e-commerce connection:", error);
      res.status(500).json({ message: "Failed to update e-commerce connection" });
    }
  });
  
  // Mock e-commerce sales data for demonstration
  app.get("/api/ecommerce/sales-data", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // This is a placeholder. In a real implementation, we would fetch real data
    // from the connected e-commerce platforms using their APIs with the stored
    // API credentials from the ecommerceConnections table.
    
    // Return sample data structure that would be returned from real integrations
    res.json({
      platforms: [
        {
          name: "Shopify",
          connected: true,
          data: {
            totalSales: "23450.75",
            totalOrders: "347",
            averageOrderValue: "67.58",
            conversionRate: "3.2",
            topProducts: [
              { name: "Black T-Shirt - Medium", sales: "4500.00", quantity: 75 },
              { name: "Gray Hoodie - Large", sales: "3200.50", quantity: 32 },
              { name: "Blue Baseball Cap", sales: "2800.25", quantity: 28 }
            ],
            recentOrders: [
              { id: "ORD-12345", total: "89.99", customer: "John D.", status: "completed", date: new Date().toISOString() },
              { id: "ORD-12346", total: "149.50", customer: "Sarah M.", status: "processing", date: new Date().toISOString() }
            ]
          }
        },
        {
          name: "WooCommerce",
          connected: false
        }
      ]
    });
  });
}