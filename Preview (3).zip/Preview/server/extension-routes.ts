/**
 * Lab AI Analytics Extension API Routes
 * 
 * This file contains the API routes specifically for the Chrome extension.
 * These routes handle authentication, website tracking activation, and data collection.
 */

import express, { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { nanoid } from 'nanoid';
import { storage } from './storage';

// JWT secret key (should be in environment variables in production)
const JWT_SECRET = process.env.JWT_SECRET || 'labai-extension-secret-key';
const JWT_EXPIRY = '30d'; // 30 days token expiry

/**
 * Register extension API routes
 * @param app Express application
 */
export function registerExtensionRoutes(app: express.Express) {
  /**
   * Extension authentication endpoint
   * Authenticates users via email/password for extension use
   */
  app.post('/api/extension/auth', async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ 
          success: false, 
          error: 'Email and password are required' 
        });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid credentials' 
        });
      }
      
      // Verify password - assuming comparePasswords function exists in routes.ts
      // You may need to import or duplicate that function here
      // or implement a proper authentication mechanism
      const isValidPassword = await comparePasswords(password, user.password);
      
      if (!isValidPassword) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid credentials' 
        });
      }
      
      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRY }
      );
      
      // Return user info and token
      res.status(200).json({
        success: true,
        userId: user.id,
        email: user.email,
        token
      });
    } catch (error) {
      console.error('Extension auth error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Authentication failed' 
      });
    }
  });

  /**
   * Website analysis endpoint
   * Stores website analysis results from the extension
   */
  app.post('/api/extension/analysis', authenticateToken, async (req: Request, res: Response) => {
    try {
      const { url, analysisData, timestamp } = req.body;
      const userId = (req.user as any)?.userId; // Type assertion to handle userId property
      
      if (!url || !analysisData) {
        return res.status(400).json({ 
          success: false, 
          error: 'URL and analysis data are required' 
        });
      }
      
      // Extract domain from URL
      let domain;
      try {
        domain = new URL(url).hostname;
      } catch (e) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid URL' 
        });
      }
      
      // Find if this website is already tracked
      const existingWebsite = await storage.getTrackedWebsiteByDomain(userId, domain);
      
      // If not tracked, create a new tracking record
      if (!existingWebsite) {
        // Generate trackingId
        const trackingId = generateTrackingId();
        
        // Create a new tracked website
        const newWebsite = await storage.createTrackedWebsite({
          userId,
          domain,
          trackingId,
          name: analysisData.title || domain,
          status: 'active'
        });
        
        // Store analysis data
        await storeAnalysisData(newWebsite.id, analysisData, timestamp);
        
        return res.status(201).json({
          success: true,
          message: 'Website added and analysis stored',
          websiteId: newWebsite.id,
          trackingId
        });
      }
      
      // Store analysis data for existing website
      await storeAnalysisData(existingWebsite.id, analysisData, timestamp);
      
      res.status(200).json({
        success: true,
        message: 'Analysis data stored',
        websiteId: existingWebsite.id,
        trackingId: existingWebsite.trackingId
      });
    } catch (error) {
      console.error('Extension analysis error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to store analysis data' 
      });
    }
  });

  /**
   * Analytics data retrieval endpoint
   * Gets analytics data for a specific website
   */
  app.post('/api/extension/analytics/:websiteId', authenticateToken, async (req: Request, res: Response) => {
    try {
      const { websiteId } = req.params;
      const { timeRange } = req.body;
      const userId = (req.user as any)?.userId;
      
      // Check if website belongs to user
      const website = await storage.getTrackedWebsiteById(parseInt(websiteId));
      
      if (!website || website.userId !== userId) {
        return res.status(404).json({ 
          success: false, 
          error: 'Website not found' 
        });
      }
      
      // Set default time range if not provided
      const defaultTimeRange = {
        from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
        to: new Date().toISOString()
      };
      
      const range = timeRange || defaultTimeRange;
      
      // Get analytics data
      const analyticsData = await getWebsiteAnalytics(parseInt(websiteId), range.from, range.to);
      
      res.status(200).json({
        success: true,
        websiteId,
        timeRange: range,
        data: analyticsData
      });
    } catch (error) {
      console.error('Extension analytics error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to retrieve analytics data' 
      });
    }
  });

  /**
   * Event tracking endpoint
   * Receives and stores event data from the extension
   */
  app.post('/api/extension/events', authenticateToken, async (req: Request, res: Response) => {
    try {
      const { events } = req.body;
      const userId = (req.user as any)?.userId;
      
      if (!events || !Array.isArray(events) || events.length === 0) {
        return res.status(400).json({ 
          success: false, 
          error: 'Events data is required' 
        });
      }
      
      // Process and store events
      const results = await Promise.all(events.map(async (event) => {
        try {
          // Verify website belongs to user
          const website = await storage.getTrackedWebsiteById(event.websiteId);
          
          if (!website || website.userId !== userId) {
            return { success: false, error: 'Invalid website ID', event };
          }
          
          // Store event based on type
          switch (event.type) {
            case 'page_view':
              await storage.recordPageView({
                websiteId: event.websiteId,
                url: event.url,
                path: new URL(event.url).pathname,
                title: event.data.title,
                referrer: event.data.referrer,
                visitorId: event.visitorId,
                sessionId: event.sessionId,
                userAgent: event.data.userAgent || null,
                browser: event.data.browser || null,
                os: event.data.os || null,
                device: event.data.device || null,
                country: event.data.country || null,
                city: event.data.city || null,
                timestamp: event.timestamp || new Date().toISOString()
              });
              break;
              
            case 'click':
            case 'form_submit':
            case 'scroll_depth':
            case 'page_exit':
              await storage.recordEvent({
                websiteId: event.websiteId,
                url: event.url,
                path: new URL(event.url).pathname,
                eventType: event.type,
                eventCategory: event.data?.category || null,
                eventAction: event.data?.action || null,
                eventLabel: event.data?.label || null,
                eventValue: event.data?.value || null,
                elementId: event.data?.elementId || null,
                elementClass: event.data?.elementClass || null,
                elementType: event.data?.elementType || null,
                elementText: event.data?.elementText || null,
                formData: event.data?.formData ? JSON.stringify(event.data.formData) : null,
                visitorId: event.visitorId || null,
                sessionId: event.sessionId || null,
                timestamp: event.timestamp || new Date().toISOString()
              });
              break;
              
            default:
              // Store any other event types
              await storage.recordEvent({
                websiteId: event.websiteId,
                url: event.url,
                path: new URL(event.url).pathname,
                eventType: event.type,
                eventCategory: event.data?.category || null,
                eventAction: event.data?.action || null,
                eventLabel: event.data?.label || null,
                eventValue: event.data?.value || null,
                elementId: event.data?.elementId || null,
                elementClass: event.data?.elementClass || null,
                elementType: event.data?.elementType || null,
                elementText: event.data?.elementText || null,
                formData: event.data?.formData ? JSON.stringify(event.data.formData) : null,
                visitorId: event.visitorId || null,
                sessionId: event.sessionId || null,
                timestamp: event.timestamp || new Date().toISOString()
              });
          }
          
          return { success: true, event };
        } catch (error) {
          console.error('Event processing error:', error);
          return { success: false, error: 'Failed to process event', event };
        }
      }));
      
      // Check if all events were processed successfully
      const allSuccessful = results.every(result => result.success);
      
      if (allSuccessful) {
        res.status(200).json({
          success: true,
          message: 'All events processed successfully',
          count: events.length
        });
      } else {
        // Some events failed, but we still processed some
        const successCount = results.filter(result => result.success).length;
        
        res.status(207).json({
          success: true,
          message: 'Some events processed successfully',
          count: successCount,
          total: events.length,
          failures: results.filter(result => !result.success).length
        });
      }
    } catch (error) {
      console.error('Extension events error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to process events' 
      });
    }
  });
}

/**
 * Middleware to authenticate JWT token
 */
function authenticateToken(req: Request, res: Response, next: any) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Authentication token required'
    });
  }
  
  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({
        success: false,
        error: 'Invalid or expired token'
      });
    }
    
    req.user = user;
    next();
  });
}

/**
 * Generate a tracking ID for a website
 */
function generateTrackingId(): string {
  // Generate a unique ID with lowercase characters
  return `trk_${nanoid(16).toLowerCase()}`;
}

/**
 * Store website analysis data
 * @param websiteId Website ID
 * @param analysisData Analysis data
 * @param timestamp Timestamp
 */
async function storeAnalysisData(websiteId: number, analysisData: any, timestamp: string) {
  // Store analysis data in the database
  // This function would interact with a model specifically for analysis data
  // For now, we'll log it and implement storage later
  console.log(`Storing analysis data for website ID ${websiteId}`);
  
  // In a real implementation, you would store this in the database
  // await storage.createAnalysisRecord({
  //   websiteId,
  //   data: JSON.stringify(analysisData),
  //   timestamp: new Date(timestamp)
  // });
}

/**
 * Get website analytics data
 * @param websiteId Website ID
 * @param fromDate Start date
 * @param toDate End date
 */
async function getWebsiteAnalytics(websiteId: number, fromDate: string, toDate: string) {
  // Get analytics data from storage
  const from = new Date(fromDate);
  const to = new Date(toDate);
  
  // Get page views
  const pageViews = await storage.getPageViewsByWebsite(websiteId, from, to);
  
  // Get events
  const events = await storage.getEventsByWebsite(websiteId, from, to);
  
  // Process and aggregate data
  // ... (this would involve complex data processing logic)
  
  // For now, return a simple format
  return {
    pageViews,
    events,
    summary: {
      totalPageViews: pageViews.length,
      totalEvents: events.length,
      uniqueVisitors: countUniqueVisitors(pageViews),
      topPages: getTopPages(pageViews)
    }
  };
}

/**
 * Count unique visitors from page view data
 * @param pageViews Page view data
 */
function countUniqueVisitors(pageViews: any[]) {
  const visitorIds = new Set();
  
  pageViews.forEach(view => {
    if (view.visitorId) {
      visitorIds.add(view.visitorId);
    }
  });
  
  return visitorIds.size;
}

/**
 * Get top pages from page view data
 * @param pageViews Page view data
 */
function getTopPages(pageViews: any[]) {
  const pageCount: { [key: string]: number } = {};
  
  pageViews.forEach(view => {
    const path = view.path || '/';
    pageCount[path] = (pageCount[path] || 0) + 1;
  });
  
  // Convert to array and sort
  const sortedPages = Object.entries(pageCount)
    .map(([path, count]) => ({ path, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10); // Top 10 pages
  
  return sortedPages;
}

/**
 * Compare passwords (placeholder - use the actual function from your auth system)
 * @param supplied Supplied password
 * @param stored Stored password hash
 */
async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  // This is a placeholder. Use your actual password comparison function.
  // You might need to import or duplicate the function from routes.ts.
  
  // Example implementation (you should replace this with your actual implementation)
  return supplied === stored; // This is NOT secure, replace with proper comparison
}