// Mock file for static asset imports
module.exports = 'test-file-stub';