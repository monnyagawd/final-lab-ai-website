import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Check } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import Navbar from '@/components/Navbar';

interface PricingTier {
  name: string;
  description: string;
  price: number;
  features: string[];
  buttonText: string;
  popular?: boolean;
  priceId?: string;
}

const packages = {
  starter: [
    {
      name: 'Starter Basic',
      description: 'The essentials for small businesses',
      price: 750,
      features: [
        'Custom website design',
        'Mobile responsive design',
        'Contact form',
        'Basic SEO optimization',
        '1 month of support'
      ],
      buttonText: 'Choose Basic',
      priceId: 'price_starter_basic'
    },
    {
      name: 'Starter Plus',
      description: 'Enhanced features for growing businesses',
      price: 1000,
      features: [
        'All Basic features',
        'Logo design',
        'Social media integration',
        'Google Analytics setup',
        '3 months of support'
      ],
      buttonText: 'Choose Plus',
      priceId: 'price_starter_plus'
    }
  ],
  growth: [
    {
      name: 'Growth Essential',
      description: 'Comprehensive solution for established businesses',
      price: 1500,
      features: [
        'Advanced website design',
        'E-commerce integration',
        'Content management system',
        'SEO optimization',
        '3 months of support',
        'Social media setup'
      ],
      buttonText: 'Choose Essential',
      priceId: 'price_growth_essential'
    },
    {
      name: 'Growth Plus',
      description: 'Premium solution with advanced features',
      price: 1750,
      features: [
        'All Essential features',
        'Email marketing integration',
        'Custom forms & surveys',
        'Advanced analytics dashboard',
        '6 months of support',
        'Premium design elements'
      ],
      buttonText: 'Choose Plus',
      priceId: 'price_growth_plus'
    },
    {
      name: 'Growth Pro',
      description: 'Complete solution for serious growth',
      price: 2000,
      features: [
        'All Plus features',
        'Custom integrations',
        'Loyalty program setup',
        'Advanced security features',
        '12 months of support',
        'Premium hosting'
      ],
      buttonText: 'Choose Pro',
      priceId: 'price_growth_pro'
    }
  ],
  pro: [
    {
      name: 'Pro Standard',
      description: 'Enterprise-grade solution',
      price: 2500,
      features: [
        'Custom enterprise website',
        'Full e-commerce suite',
        'Advanced security',
        'Premium hosting',
        'SEO optimization',
        '12 months of priority support',
        'Dedicated account manager'
      ],
      buttonText: 'Choose Standard',
      priceId: 'price_pro_standard'
    },
    {
      name: 'Pro Advanced',
      description: 'Comprehensive enterprise solution',
      price: 3250,
      features: [
        'All Standard features',
        'Custom API integrations',
        'Advanced analytics dashboard',
        'A/B testing setup',
        'User testing & feedback',
        'Conversion optimization',
        'Performance optimization'
      ],
      buttonText: 'Choose Advanced',
      priceId: 'price_pro_advanced'
    },
    {
      name: 'Pro Elite',
      description: 'Ultimate enterprise solution',
      price: 4000,
      features: [
        'All Advanced features',
        'Custom AI integration',
        'Multilingual support',
        'International SEO',
        'Advanced security audit',
        '24/7 priority support',
        'Quarterly strategy sessions'
      ],
      buttonText: 'Choose Elite',
      priceId: 'price_pro_elite'
    }
  ]
};

export default function PackagesPage() {
  const [, setLocation] = useLocation();
  const [pricingInterval, setPricingInterval] = useState<'month' | 'year'>('month');
  const { user } = useAuth();

  const handlePackageSelect = (pkg: PricingTier, tier: string) => {
    // For subscription packages, direct to the subscription page
    if (pricingInterval === 'month' || pricingInterval === 'year') {
      const params = new URLSearchParams({
        plan: pkg.name,
        price: pkg.price.toString(),
        interval: pricingInterval,
        priceId: pkg.priceId || ''
      });
      
      setLocation(`/subscribe?${params.toString()}`);
    } else {
      // For one-time payments, direct to the checkout page
      const params = new URLSearchParams({
        package: pkg.name,
        amount: pkg.price.toString(),
        tier: tier
      });
      
      setLocation(`/checkout?${params.toString()}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-6 pt-24 pb-10 max-w-7xl">
      <div className="mx-auto text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
          Choose Your Website Package
        </h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Select the perfect package to match your business needs. All packages include a custom website,
          responsive design, and ongoing support.
        </p>
      </div>

      <Tabs defaultValue="starter" className="w-full">
        <div className="flex flex-col items-center mb-8 space-y-4">
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="starter">Starter</TabsTrigger>
            <TabsTrigger value="growth">Growth</TabsTrigger>
            <TabsTrigger value="pro">Pro Custom</TabsTrigger>
          </TabsList>
          
          {/* We can enable this when we support recurring payments */}
          {/* <div className="flex items-center space-x-2">
            <span className={pricingInterval === 'month' ? 'text-foreground' : 'text-muted-foreground'}>
              Monthly
            </span>
            <Switch
              checked={pricingInterval === 'year'}
              onCheckedChange={(checked) => 
                setPricingInterval(checked ? 'year' : 'month')
              }
              aria-label="Toggle yearly billing"
            />
            <span className={pricingInterval === 'year' ? 'text-foreground flex items-center' : 'text-muted-foreground flex items-center'}>
              Yearly
              {pricingInterval === 'year' && (
                <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-800">
                  Save 20%
                </span>
              )}
            </span>
          </div> */}
        </div>
        
        <TabsContent value="starter" className="space-y-8">
          <div className="grid md:grid-cols-2 gap-8 items-stretch">
            {packages.starter.map((pkg, i) => (
              <PricingCard 
                key={i}
                tier={pkg}
                handleSelect={() => handlePackageSelect(pkg, 'starter')}
                interval="one-time"
                borderStyle="border-2 border-purple-300 shadow-lg shadow-purple-300/20"
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="growth" className="space-y-8">
          <div className="grid md:grid-cols-3 gap-8 items-stretch">
            {packages.growth.map((pkg, i) => (
              <PricingCard 
                key={i}
                tier={pkg}
                handleSelect={() => handlePackageSelect(pkg, 'growth')}
                interval="one-time"
                borderStyle="border-2 border-purple-500 shadow-lg shadow-purple-500/30"
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="pro" className="space-y-8">
          <div className="grid md:grid-cols-3 gap-8 items-stretch">
            {packages.pro.map((pkg, i) => (
              <PricingCard 
                key={i}
                tier={pkg}
                handleSelect={() => handlePackageSelect(pkg, 'pro')}
                interval="one-time"
                borderStyle="border-2 border-purple-700 shadow-lg shadow-purple-700/40"
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Monthly Maintenance Fee Section */}
      <div className="mt-16 py-12 border-t">
        <div className="mx-auto text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-4">
            Website Maintenance Membership - Tiered Packages
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Keep your website running smoothly with our comprehensive maintenance plans
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-stretch">
          {/* Basic Tier */}
          <Card className="flex flex-col border-2 border-purple-300 shadow-lg shadow-purple-300/20">
            <CardHeader className="text-center">
              <CardTitle className="text-xl">Basic Tier</CardTitle>
              <div className="text-3xl font-bold text-primary mt-2">
                $150<span className="text-lg font-normal text-muted-foreground">/month</span>
              </div>
              <div className="text-sm text-muted-foreground">
                $900 total (6-month price)
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Monthly Edit Time</h4>
                  <p className="text-sm text-muted-foreground">1 hour</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Support Response Time</h4>
                  <p className="text-sm text-muted-foreground">Within 72 hours</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Updates & Backups</h4>
                  <p className="text-sm text-muted-foreground">Weekly plugin updates, Weekly backups</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Monitoring</h4>
                  <p className="text-sm text-muted-foreground">None</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Included Services</h4>
                  <p className="text-sm text-muted-foreground">Basic</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Base Work Rate</h4>
                  <p className="text-sm text-muted-foreground">$100/hr</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Renewal</h4>
                  <p className="text-sm text-muted-foreground">Monthly billing</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Refund Policy</h4>
                  <p className="text-sm text-muted-foreground">Cancel anytime (maintenance stops at end of paid period)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Standard Tier */}
          <Card className="flex flex-col border-2 border-purple-500 shadow-lg shadow-purple-500/30">
            <CardHeader className="text-center">
              <CardTitle className="text-xl">Standard Tier</CardTitle>
              <div className="text-3xl font-bold text-primary mt-2">
                $180<span className="text-lg font-normal text-muted-foreground">/month</span>
              </div>
              <div className="text-sm text-muted-foreground">
                $1,080 total (6-month price)
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Monthly Edit Time</h4>
                  <p className="text-sm text-muted-foreground">2 hours</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Support Response Time</h4>
                  <p className="text-sm text-muted-foreground">Within 48 hours</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Updates & Backups</h4>
                  <p className="text-sm text-muted-foreground">Daily backups, Weekly updates</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Monitoring</h4>
                  <p className="text-sm text-muted-foreground">Uptime monitoring</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Included Services</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>Text/image swaps, Minor edits (under 20 mins), Basic troubleshooting</p>
                    <p>SEO updates, Core plugin uploads</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Base Work Rate</h4>
                  <p className="text-sm text-muted-foreground">$100/hr</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Renewal</h4>
                  <p className="text-sm text-muted-foreground">Manual after 12 months or renew monthly</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Refund Policy</h4>
                  <p className="text-sm text-muted-foreground">No refunds after payment</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Premium Tier */}
          <Card className="flex flex-col border-2 border-purple-700 shadow-lg shadow-purple-700/40">
            <CardHeader className="text-center">
              <CardTitle className="text-xl">Premium Tier</CardTitle>
              <div className="text-3xl font-bold text-primary mt-2">
                $275<span className="text-lg font-normal text-muted-foreground">/month</span>
              </div>
              <div className="text-sm text-muted-foreground">
                $1,650 total (6-month price)
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Monthly Edit Time</h4>
                  <p className="text-sm text-muted-foreground">4 hours</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Support Response Time</h4>
                  <p className="text-sm text-muted-foreground">Within 24 hours</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Updates & Backups</h4>
                  <p className="text-sm text-muted-foreground">Daily updates & backups</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Monitoring</h4>
                  <p className="text-sm text-muted-foreground">Uptime + performance monitoring</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Included Services</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>All Basic features plus:</p>
                    <p>Priority edits, Website Site performance optimization, Security health check</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Base Work Rate</h4>
                  <p className="text-sm text-muted-foreground">$90/hr</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Renewal</h4>
                  <p className="text-sm text-muted-foreground">Manual after 12 months or renew monthly</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Refund Policy</h4>
                  <p className="text-sm text-muted-foreground">No refunds after payment</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Time Estimates Table */}
        <div className="mt-12 pt-8 border-t">
          <div className="mx-auto text-center mb-8">
            <h3 className="text-xl md:text-2xl font-bold tracking-tight mb-4 text-blue-600">
              Time Estimates for Typical Tasks
            </h3>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="overflow-hidden rounded-lg border">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Task</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Estimated Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  <tr className="bg-background">
                    <td className="px-6 py-4 text-sm">Text/image swaps</td>
                    <td className="px-6 py-4 text-sm">~10-15 minutes</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="px-6 py-4 text-sm">Adding content to existing page</td>
                    <td className="px-6 py-4 text-sm">~20-30 minutes</td>
                  </tr>
                  <tr className="bg-background">
                    <td className="px-6 py-4 text-sm">Layout/styling tweaks</td>
                    <td className="px-6 py-4 text-sm">~30-45 minutes</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="px-6 py-4 text-sm">Plugin troubleshooting</td>
                    <td className="px-6 py-4 text-sm">~30-60 minutes</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
}

interface PricingCardProps {
  tier: PricingTier;
  handleSelect: () => void;
  interval: 'month' | 'year' | 'one-time';
  borderStyle?: string;
}

function PricingCard({ tier, handleSelect, interval, borderStyle }: PricingCardProps) {
  const defaultBorder = tier.popular ? 'border-primary shadow-lg' : '';
  const finalBorder = borderStyle || defaultBorder;
  
  return (
    <Card className={`flex flex-col h-full ${finalBorder}`}>
      
      <CardHeader>
        <CardTitle>{tier.name}</CardTitle>
        <CardDescription>{tier.description}</CardDescription>
      </CardHeader>
      
      <CardContent className="flex-grow">
        <div className="flex items-baseline mb-5">
          <span className="text-3xl font-bold">${tier.price}</span>
          {interval !== 'one-time' && (
            <span className="ml-1 text-muted-foreground">/{interval}</span>
          )}
        </div>
        
        <ul className="space-y-3">
          {tier.features.map((feature, i) => (
            <li key={i} className="flex items-center">
              <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      
      <CardFooter>
        <Button onClick={handleSelect} className="w-full" variant={tier.popular ? 'default' : 'outline'}>
          {tier.buttonText}
        </Button>
      </CardFooter>
    </Card>
  );
}