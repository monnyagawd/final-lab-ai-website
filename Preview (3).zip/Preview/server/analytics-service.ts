/**
 * Analytics Service for Lab AI
 * 
 * This service handles processing of analytics data from page views and events
 */

import { PageView, Event } from "@shared/schema";

/**
 * Process page views into analytics data
 */
export function processAnalyticsData(pageViews: PageView[], events: Event[]) {
  // If no data, return empty stats
  if (pageViews.length === 0) {
    return createEmptyAnalytics();
  }
  
  // Process unique visitors
  const uniqueVisitorIds = new Set();
  pageViews.forEach(pv => {
    if (pv.visitorId) uniqueVisitorIds.add(pv.visitorId);
  });
  
  // Count by device type
  const deviceData = {};
  pageViews.forEach(pv => {
    const device = pv.deviceType || 'Unknown';
    deviceData[device] = (deviceData[device] || 0) + 1;
  });
  
  // Count by browser
  const browserData = {};
  pageViews.forEach(pv => {
    const browser = pv.browser || 'Unknown';
    browserData[browser] = (browserData[browser] || 0) + 1;
  });
  
  // Count by location/country
  const locationData = {};
  pageViews.forEach(pv => {
    const location = pv.country || 'Unknown';
    locationData[location] = (locationData[location] || 0) + 1;
  });
  
  // Count by page
  const pageData = {};
  pageViews.forEach(pv => {
    const page = pv.path || '/';
    pageData[page] = (pageData[page] || 0) + 1;
  });
  
  // Count by referrer
  const referrerData = {};
  pageViews.forEach(pv => {
    if (pv.referrer) {
      try {
        const referrerUrl = new URL(pv.referrer);
        const referrer = referrerUrl.hostname || pv.referrer;
        referrerData[referrer] = (referrerData[referrer] || 0) + 1;
      } catch {
        // Skip invalid URLs
      }
    }
  });
  
  // Count by hour of day
  const hourlyData = Array(24).fill(0);
  pageViews.forEach(pv => {
    if (pv.timestamp) {
      const hour = new Date(pv.timestamp).getHours();
      hourlyData[hour]++;
    }
  });
  
  // Group page views by date
  const dailyPageViews = {};
  const dailyVisitors = {};
  const start = new Date(Math.min(...pageViews.map(pv => new Date(pv.timestamp || Date.now()).getTime())));
  const end = new Date(Math.max(...pageViews.map(pv => new Date(pv.timestamp || Date.now()).getTime())));
  
  pageViews.forEach(pv => {
    if (pv.timestamp) {
      const date = new Date(pv.timestamp).toISOString().split('T')[0];
      dailyPageViews[date] = (dailyPageViews[date] || 0) + 1;
      
      if (pv.visitorId) {
        dailyVisitors[date] = dailyVisitors[date] || new Set();
        dailyVisitors[date].add(pv.visitorId);
      }
    }
  });
  
  // Create daily traffic data
  const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (24 * 60 * 60 * 1000)));
  const trafficByDay = [];
  
  for (let i = 0; i < days; i++) {
    const date = new Date(start);
    date.setDate(date.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];
    
    trafficByDay.push({
      date: dateStr,
      visitors: dailyVisitors[dateStr] ? dailyVisitors[dateStr].size : 0,
      pageViews: dailyPageViews[dateStr] || 0
    });
  }
  
  // Process events
  const eventCounts = {};
  events.forEach(event => {
    const type = event.eventType || 'Unknown';
    eventCounts[type] = (eventCounts[type] || 0) + 1;
  });
  
  // Format data for response
  const totalPageViews = pageViews.length;
  
  // Calculate statistics
  const visitorsByDevice = Object.entries(deviceData).map(([device, count]) => ({
    device,
    count: count as number,
    percentage: Math.round((count as number / totalPageViews) * 100 * 10) / 10
  })).sort((a, b) => b.count - a.count);
  
  const visitorsByBrowser = Object.entries(browserData).map(([browser, count]) => ({
    browser,
    count: count as number,
    percentage: Math.round((count as number / totalPageViews) * 100 * 10) / 10
  })).sort((a, b) => b.count - a.count);
  
  const visitorsByLocation = Object.entries(locationData).map(([location, count]) => ({
    location,
    count: count as number,
    percentage: Math.round((count as number / totalPageViews) * 100 * 10) / 10
  })).sort((a, b) => b.count - a.count);
  
  const topPages = Object.entries(pageData).map(([url, count]) => ({
    url,
    count: count as number,
    bounceRate: 0,
    avgTime: 0
  })).sort((a, b) => b.count - a.count);
  
  const topReferrers = Object.entries(referrerData).map(([url, count]) => ({
    url,
    count: count as number,
    percentage: Math.round((count as number / totalPageViews) * 100 * 10) / 10
  })).sort((a, b) => b.count - a.count);
  
  const trafficByHour = hourlyData.map((count, hour) => ({ hour, count }));
  
  const processedEvents = Object.entries(eventCounts).map(([name, count]) => ({
    name,
    count: count as number,
    value: 0
  })).sort((a, b) => b.count - a.count);
  
  // Return the processed analytics data
  return {
    uniqueVisitors: uniqueVisitorIds.size,
    pageViewCount: totalPageViews,
    bounceRate: 0,
    averageSessionDuration: 0,
    visitorsByDevice,
    visitorsByBrowser,
    visitorsByLocation,
    trafficByHour,
    trafficByDay,
    topPages,
    topReferrers,
    events: processedEvents,
    conversionRate: 0,
    comparisonStats: {
      visitorsChange: 0,
      pageViewsChange: 0,
      bounceRateChange: 0,
      durationChange: 0
    },
    timeframe: {
      start: start.toISOString(),
      end: end.toISOString()
    }
  };
}

/**
 * Create empty analytics structure
 */
function createEmptyAnalytics() {
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  
  return {
    uniqueVisitors: 0,
    pageViewCount: 0,
    bounceRate: 0,
    averageSessionDuration: 0,
    visitorsByDevice: [],
    visitorsByBrowser: [],
    visitorsByLocation: [],
    trafficByHour: Array.from({ length: 24 }, (_, i) => ({ hour: i, count: 0 })),
    trafficByDay: [],
    topPages: [],
    topReferrers: [],
    events: [],
    conversionRate: 0,
    comparisonStats: {
      visitorsChange: 0,
      pageViewsChange: 0,
      bounceRateChange: 0,
      durationChange: 0
    },
    timeframe: {
      start: thirtyDaysAgo.toISOString(),
      end: now.toISOString()
    }
  };
}