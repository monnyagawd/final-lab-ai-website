/**
 * Stripe utilities for the Lab AI platform
 */
import Stripe from 'stripe';

// Initialize Stripe with the secret key from environment variables
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is not set in the environment variables');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

/**
 * Create a payment intent for a one-time payment
 * @param amount The amount to charge in dollars (will be converted to cents)
 * @param metadata Optional metadata to attach to the payment intent
 * @returns The created payment intent
 */
export async function createPaymentIntent(amount: number, metadata?: Record<string, string>): Promise<Stripe.PaymentIntent> {
  const amountInCents = Math.round(amount * 100);
  
  return await stripe.paymentIntents.create({
    amount: amountInCents,
    currency: 'usd',
    metadata
  });
}

/**
 * Create a new subscription for a customer
 * @param customerId The Stripe customer ID
 * @param priceId The Stripe price ID for the subscription
 * @param metadata Optional metadata to attach to the subscription
 * @returns The created subscription
 */
export async function createSubscription(
  customerId: string,
  priceId: string,
  metadata?: Record<string, string>
): Promise<Stripe.Subscription> {
  return await stripe.subscriptions.create({
    customer: customerId,
    items: [{ price: priceId }],
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent'],
    metadata
  });
}

/**
 * Create a new customer in Stripe
 * @param email The customer's email
 * @param name The customer's name
 * @param metadata Optional metadata to attach to the customer
 * @returns The created customer
 */
export async function createCustomer(
  email: string,
  name?: string,
  metadata?: Record<string, string>
): Promise<Stripe.Customer> {
  return await stripe.customers.create({
    email,
    name,
    metadata
  });
}

/**
 * Retrieve a customer from Stripe
 * @param customerId The Stripe customer ID
 * @returns The customer object
 */
export async function getCustomer(customerId: string): Promise<Stripe.Customer> {
  return await stripe.customers.retrieve(customerId);
}

/**
 * Retrieve a subscription from Stripe
 * @param subscriptionId The Stripe subscription ID
 * @param expand Optional related objects to expand in the response
 * @returns The subscription object
 */
export async function getSubscription(subscriptionId: string, expand?: string[]): Promise<Stripe.Subscription> {
  return await stripe.subscriptions.retrieve(subscriptionId, { expand });
}

/**
 * Cancel a subscription in Stripe
 * @param subscriptionId The Stripe subscription ID
 * @param options Optional options for cancellation
 * @returns The canceled subscription
 */
export async function cancelSubscription(
  subscriptionId: string,
  options?: Stripe.SubscriptionCancelParams
): Promise<Stripe.Subscription> {
  return await stripe.subscriptions.cancel(subscriptionId, options);
}

/**
 * Update a subscription in Stripe
 * @param subscriptionId The Stripe subscription ID
 * @param params The update parameters
 * @returns The updated subscription
 */
export async function updateSubscription(
  subscriptionId: string,
  params: Stripe.SubscriptionUpdateParams
): Promise<Stripe.Subscription> {
  return await stripe.subscriptions.update(subscriptionId, params);
}

/**
 * Retrieve balance from Stripe
 * @returns The balance object
 */
export async function getBalance(): Promise<Stripe.Balance> {
  return await stripe.balance.retrieve();
}

/**
 * Verify webhook event signature
 * @param payload The raw request body
 * @param signature The signature from the Stripe-Signature header
 * @param webhookSecret The webhook secret for verification
 * @returns The verified event
 */
export async function verifyWebhookEvent(
  payload: string | Buffer,
  signature: string,
  webhookSecret: string
): Promise<Stripe.Event> {
  return stripe.webhooks.constructEvent(
    payload,
    signature,
    webhookSecret
  );
}

// Export the Stripe instance for direct use
export { stripe };