import { pgTable, text, serial, timestamp, boolean, json, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  companyName: text("company_name"),
  role: text("role").default("customer"),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  websiteStatus: text("website_status").default("offline"),
  websiteName: text("website_name"),
  websiteUrl: text("website_url"),
});

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  projectType: text("project_type").notNull(),
  message: text("message").notNull(),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  projectType: text("project_type").notNull(),
  projectDetails: text("project_details").notNull(),
  appointmentDate: text("appointment_date").notNull(), // Store as ISO string
  appointmentTime: text("appointment_time").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, confirmed, cancelled, completed
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Define available time slots for a given date
export const availableSlots = pgTable("available_slots", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // Format: YYYY-MM-DD
  timeSlot: text("time_slot").notNull(), // Format: HH:MM AM/PM
  isAvailable: boolean("is_available").notNull().default(true),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Website analytics for each user
export const websiteAnalytics = pgTable("website_analytics", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  // Core metrics
  pageViews: text("page_views").default("0"),
  uniqueVisitors: text("unique_visitors").default("0"),
  bounceRate: text("bounce_rate").default("0"),
  avgTimeOnSite: text("avg_time_on_site").default("0"),
  
  // Time periods
  dailyVisitors: text("daily_visitors").default("0"),
  weeklyVisitors: text("weekly_visitors").default("0"),
  monthlyVisitors: text("monthly_visitors").default("0"),
  
  // Page and referral data
  topReferrers: text("top_referrers"),
  topPages: text("top_pages"),
  topCountries: text("top_countries"),
  topCities: text("top_cities"),
  
  // Real-time data
  currentVisitors: text("current_visitors").default("0"),
  
  // Device data
  deviceBreakdown: text("device_breakdown"), // JSON string: { desktop: "65", mobile: "30", tablet: "5" }
  
  // Conversion data
  conversionRate: text("conversion_rate").default("0"),
  
  // SEO data
  seoSummary: text("seo_summary"), // JSON string with overview of SEO performance
  
  // Heatmap data
  heatmapData: text("heatmap_data"), // JSON string with click data
  
  // Traffic trend data
  trafficTrend: text("traffic_trend"), // JSON string with historical traffic data
  
  lastUpdated: text("last_updated").notNull().$defaultFn(() => new Date().toISOString()),
});

// Social media connections and analytics
export const socialMediaAccounts = pgTable("social_media_accounts", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  platform: text("platform").notNull(), // discord, tiktok, instagram, twitter, facebook, youtube
  accountId: text("account_id"),
  accountName: text("account_name"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: text("token_expiry"),
  
  // Core metrics
  followers: text("followers").default("0"),
  following: text("following").default("0"),
  engagement: text("engagement").default("0"),
  profileViews: text("profile_views").default("0"),
  impressions: text("impressions").default("0"),
  
  // Engagement metrics
  likes: text("likes").default("0"),
  comments: text("comments").default("0"),
  shares: text("shares").default("0"),
  posts: text("posts").default("0"),
  
  // Content performance
  recentPostData: text("recent_post_data"), // JSON string containing data about recent posts
  topPerformingPosts: text("top_performing_posts"), // JSON string with highest engagement posts
  
  // Growth metrics
  growthRate: text("growth_rate").default("0"), // Monthly follower growth rate percentage
  followersHistory: text("followers_history"), // JSON string with historical follower counts
  
  // Reach and visibility
  topPostReach: text("top_post_reach").default("0"),
  storyViews: text("story_views").default("0"), // For Instagram/Facebook
  
  // Click metrics
  clickThroughRate: text("click_through_rate").default("0"), // % of users who clicked links
  linkClicks: text("link_clicks").default("0"), // Total link clicks
  
  // Audience data
  demographicData: text("demographic_data"), // JSON string containing demographic breakdowns
  audienceInterests: text("audience_interests"), // JSON string with audience interests
  
  // Conversions
  conversionRate: text("conversion_rate").default("0"), // Percentage of followers who visit website
  
  // Platform-specific metrics
  // Discord
  serverMembers: text("server_members").default("0"), // For Discord
  activeUsers: text("active_users").default("0"), // For Discord
  messagesSent: text("messages_sent").default("0"), // For Discord
  
  // TikTok
  videoViews: text("video_views").default("0"), // For TikTok
  videoCompletion: text("video_completion").default("0"), // For TikTok - % who watch full video
  
  // Twitter/X
  retweets: text("retweets").default("0"), // For Twitter
  mentions: text("mentions").default("0"), // For Twitter
  
  // Tracking
  mentionsTrackingData: text("mentions_tracking_data"), // JSON string with mention history
  tagsTrackingData: text("tags_tracking_data"), // JSON string with tag history
  
  // Summary reports
  weeklyReportData: text("weekly_report_data"), // JSON string with weekly summary data
  monthlyReportData: text("monthly_report_data"), // JSON string with monthly summary data
  
  lastFetched: text("last_fetched").notNull().$defaultFn(() => new Date().toISOString()),
});

// Notifications for users
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // success, warning, error, info
  isRead: boolean("is_read").default(false),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  price: text("price").notNull(),
  sku: text("sku"),
  inventoryCount: integer("inventory_count").default(0),
  imageUrl: text("image_url"),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Orders table
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  orderNumber: text("order_number").notNull().unique(),
  orderDate: text("order_date").notNull().$defaultFn(() => new Date().toISOString()),
  totalAmount: text("total_amount").notNull(),
  status: text("status").notNull().default("pending"), // pending, processing, shipped, delivered, canceled
  paymentStatus: text("payment_status").notNull().default("paid"), // paid, pending, refunded
  
  // Customer information
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  
  // Shipping information
  shippingAddress: text("shipping_address").notNull(),
  shippingCity: text("shipping_city").notNull(),
  shippingState: text("shipping_state").notNull(),
  shippingZip: text("shipping_zip").notNull(),
  shippingCountry: text("shipping_country").notNull().default("United States"),
  
  // Billing information
  billingAddress: text("billing_address"),
  billingCity: text("billing_city"),
  billingState: text("billing_state"),
  billingZip: text("billing_zip"),
  billingCountry: text("billing_country"),
  
  // Notes
  customerNotes: text("customer_notes"),
  internalNotes: text("internal_notes"),
  
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Order Items (line items in an order)
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: serial("order_id").references(() => orders.id),
  productId: integer("product_id"), // Optional, can be null for custom items
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: text("unit_price").notNull(),
  subtotal: text("subtotal").notNull(),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Shipments table
export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  orderId: serial("order_id").references(() => orders.id),
  trackingNumber: text("tracking_number"),
  trackingUrl: text("tracking_url"),
  carrier: text("carrier"), // USPS, FedEx, UPS, etc.
  shippingMethod: text("shipping_method"), // Standard, Express, etc.
  shippingCost: text("shipping_cost"),
  status: text("status").notNull().default("pending"), // pending, in_transit, delivered
  labelUrl: text("label_url"), // URL to shipping label
  packageWeight: text("package_weight"),
  dimensions: text("dimensions"), // JSON string with dimensions
  shippedDate: text("shipped_date"),
  estimatedDeliveryDate: text("estimated_delivery_date"),
  deliveredDate: text("delivered_date"),
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Shipping providers settings and API keys
export const shippingProviders = pgTable("shipping_providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // "Shippo", "ShipStation", "EasyPost"
  apiKey: text("api_key"),
  apiSecret: text("api_secret"),
  active: boolean("active").default(true),
  settings: text("settings"), // JSON string with provider-specific settings
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Inventory items for users to track their products
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),  // Added category field
  price: text("price").notNull(),
  sku: text("sku").notNull(),
  quantity: integer("quantity").notNull().default(0),
  lowStockThreshold: integer("low_stock_threshold").notNull().default(10),
  imageUrls: text("image_urls"), // Store as JSON array string
  imageUrl: text("image_url"),   // Added for backward compatibility with UI
  platformId: text("platform_id"), // ID of the item on external platform (Shopify, WooCommerce)
  platformSku: text("platform_sku"), // SKU on external platform
  platformSource: text("platform_source"), // Which platform this item was synced from
  lastSynced: text("last_synced"), // Last time this item was synced with external platform
  status: text("status").default("active"), // active, archived, etc.
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Social media platform connections (OAuth connections)
export const socialConnections = pgTable("social_connections", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  platform: text("platform").notNull(), // facebook, twitter, instagram, tiktok, etc.
  connectionId: text("connection_id").notNull(), // Unique identifier for this connection
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: text("token_expiry"),
  platformUserId: text("platform_user_id"),
  platformUsername: text("platform_username"),
  platformProfileUrl: text("platform_profile_url"),
  platformAvatarUrl: text("platform_avatar_url"),
  status: text("status").default("active"), // active, expired, revoked
  lastSynced: text("last_synced").$defaultFn(() => new Date().toISOString()),
  metadata: text("metadata"), // JSON string with additional platform-specific data
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// E-commerce platform connections
export const ecommerceConnections = pgTable("ecommerce_connections", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  platform: text("platform").notNull(), // shopify, woocommerce, etsy, amazon, etc.
  connectionId: text("connection_id").notNull(), // Unique identifier for this connection
  shopName: text("shop_name").notNull(),
  shopUrl: text("shop_url"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: text("token_expiry"),
  apiKey: text("api_key"),
  apiSecret: text("api_secret"),
  webhookSecret: text("webhook_secret"),
  status: text("status").default("active"), // active, expired, revoked
  lastSynced: text("last_synced").$defaultFn(() => new Date().toISOString()),
  syncFrequency: text("sync_frequency").default("daily"), // realtime, hourly, daily, weekly
  syncSettings: text("sync_settings"), // JSON string with what to sync (products, orders, etc)
  metadata: text("metadata"), // JSON string with additional platform-specific data
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Website tracking
export const trackedWebsites = pgTable("tracked_websites", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  trackingId: text("tracking_id").notNull().unique(), // Unique identifier for tracking script
  domain: text("domain").notNull(),
  name: text("name"),
  status: text("status").default("active"), // active, paused, archived
  settings: text("settings"), // JSON string with tracking settings
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Page views table for tracked websites
export const pageViews = pgTable("page_views", {
  id: serial("id").primaryKey(),
  websiteId: serial("website_id").references(() => trackedWebsites.id),
  visitorId: text("visitor_id"), // Anonymous ID for tracking unique visitors
  sessionId: text("session_id"),
  url: text("url").notNull(),
  path: text("path").notNull(),
  title: text("title"),
  referrer: text("referrer"),
  userAgent: text("user_agent"),
  ip: text("ip"),
  browser: text("browser"),
  os: text("os"),
  device: text("device"), // mobile, desktop, tablet
  country: text("country"),
  region: text("region"),
  city: text("city"),
  language: text("language"),
  duration: integer("duration"), // Time on page in seconds
  bounced: boolean("bounced").default(true), // Did user leave after this page?
  entryPage: boolean("entry_page").default(false), // Was this the entry page for the session?
  exitPage: boolean("exit_page").default(false), // Was this the exit page for the session?
  timestamp: text("timestamp").notNull().$defaultFn(() => new Date().toISOString()),
});

// Events table for tracked websites (clicks, form submissions, etc.)
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  websiteId: serial("website_id").references(() => trackedWebsites.id),
  visitorId: text("visitor_id"),
  sessionId: text("session_id"),
  eventType: text("event_type").notNull(), // click, form_submit, scroll, etc.
  eventCategory: text("event_category"), // For categorizing events
  eventAction: text("event_action"), // What action was taken
  eventLabel: text("event_label"), // Additional info about the event
  eventValue: text("event_value"), // Numerical value (if applicable)
  url: text("url").notNull(),
  path: text("path").notNull(),
  elementId: text("element_id"), // ID of element that was interacted with
  elementClass: text("element_class"), // Class of element
  elementType: text("element_type"), // Type of element (button, form, etc.)
  elementText: text("element_text"), // Text of element
  formData: text("form_data"), // JSON string with form data (if applicable)
  timestamp: text("timestamp").notNull().$defaultFn(() => new Date().toISOString()),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  firstName: true,
  lastName: true,
  companyName: true,
  websiteName: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  name: true,
  email: true,
  projectType: true, 
  message: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).pick({
  fullName: true,
  email: true,
  projectType: true,
  projectDetails: true,
  appointmentDate: true,
  appointmentTime: true,
});

export const insertAvailableSlotSchema = createInsertSchema(availableSlots).pick({
  date: true,
  timeSlot: true,
  isAvailable: true,
});

// Explicitly enforce the userId is required for all these schemas
export const insertWebsiteAnalyticsSchema = createInsertSchema(websiteAnalytics)
  .pick({
    userId: true,
    // Core metrics
    pageViews: true,
    uniqueVisitors: true,
    bounceRate: true,
    avgTimeOnSite: true,
    
    // Time periods
    dailyVisitors: true,
    weeklyVisitors: true,
    monthlyVisitors: true,
    
    // Page and referral data
    topReferrers: true,
    topPages: true,
    topCountries: true,
    topCities: true,
    
    // Real-time data
    currentVisitors: true,
    
    // Device data
    deviceBreakdown: true,
    
    // Conversion data
    conversionRate: true,
    
    // SEO data
    seoSummary: true,
    
    // Heatmap data
    heatmapData: true,
    
    // Traffic trend data
    trafficTrend: true,
  })
  .required({ userId: true });

export const insertSocialMediaAccountSchema = createInsertSchema(socialMediaAccounts)
  .pick({
    userId: true,
    platform: true,
    accountId: true,
    accountName: true,
    accessToken: true,
    refreshToken: true,
    tokenExpiry: true,
    followers: true,
    following: true,
    engagement: true,
    growthRate: true,
    followersHistory: true,
  })
  .required({ userId: true, platform: true });

export const insertNotificationSchema = createInsertSchema(notifications)
  .pick({
    userId: true,
    title: true,
    message: true,
    type: true,
  })
  .required({ userId: true, title: true, message: true, type: true });

// Insert schemas for the new tables
export const insertProductSchema = createInsertSchema(products)
  .pick({
    name: true,
    description: true,
    category: true,
    price: true,
    sku: true,
    inventoryCount: true,
    imageUrl: true,
  })
  .required({ name: true, price: true });

export const insertOrderSchema = createInsertSchema(orders)
  .pick({
    userId: true,
    orderNumber: true,
    orderDate: true,
    totalAmount: true,
    status: true,
    paymentStatus: true,
    customerName: true,
    customerEmail: true,
    customerPhone: true,
    shippingAddress: true,
    shippingCity: true,
    shippingState: true,
    shippingZip: true,
    shippingCountry: true,
    billingAddress: true,
    billingCity: true,
    billingState: true,
    billingZip: true,
    billingCountry: true,
    customerNotes: true,
    internalNotes: true,
  })
  .required({ 
    userId: true,
    orderNumber: true,
    totalAmount: true,
    customerName: true,
    customerEmail: true,
    shippingAddress: true,
    shippingCity: true,
    shippingState: true,
    shippingZip: true
  });

export const insertOrderItemSchema = createInsertSchema(orderItems)
  .pick({
    orderId: true,
    productId: true,
    productName: true,
    quantity: true,
    unitPrice: true,
    subtotal: true,
  })
  .required({
    orderId: true,
    productName: true,
    quantity: true,
    unitPrice: true,
    subtotal: true,
  });

export const insertShipmentSchema = createInsertSchema(shipments)
  .pick({
    orderId: true,
    trackingNumber: true,
    trackingUrl: true,
    carrier: true,
    shippingMethod: true,
    shippingCost: true,
    status: true,
    labelUrl: true,
    packageWeight: true,
    dimensions: true,
    shippedDate: true,
    estimatedDeliveryDate: true,
    deliveredDate: true,
  })
  .required({ orderId: true });

export const insertInventoryItemSchema = createInsertSchema(inventoryItems)
  .pick({
    userId: true,
    name: true,
    description: true,
    category: true,  // Added category field
    price: true,
    sku: true,
    quantity: true,
    lowStockThreshold: true,
    imageUrls: true,
    imageUrl: true,   // Added for backward compatibility with UI
  })
  .required({ 
    userId: true,
    name: true,
    price: true,
    sku: true,
    quantity: true 
  });

export const insertShippingProviderSchema = createInsertSchema(shippingProviders)
  .pick({
    name: true,
    apiKey: true,
    apiSecret: true,
    active: true,
    settings: true,
  })
  .required({ name: true });

// Insert schemas for website tracking and connections
export const insertSocialConnectionSchema = createInsertSchema(socialConnections)
  .pick({
    userId: true,
    platform: true,
    connectionId: true,
    accessToken: true,
    refreshToken: true,
    tokenExpiry: true,
    platformUserId: true,
    platformUsername: true,
    platformProfileUrl: true,
    platformAvatarUrl: true,
    status: true,
    metadata: true,
  })
  .required({ userId: true, platform: true, connectionId: true });

export const insertEcommerceConnectionSchema = createInsertSchema(ecommerceConnections)
  .pick({
    userId: true,
    platform: true,
    connectionId: true,
    shopName: true,
    shopUrl: true,
    accessToken: true,
    refreshToken: true,
    tokenExpiry: true,
    apiKey: true,
    apiSecret: true,
    webhookSecret: true,
    status: true,
    syncFrequency: true,
    syncSettings: true,
    metadata: true,
  })
  .required({ userId: true, platform: true, connectionId: true, shopName: true });

export const insertTrackedWebsiteSchema = createInsertSchema(trackedWebsites)
  .pick({
    userId: true,
    trackingId: true,
    domain: true,
    name: true,
    status: true,
    settings: true,
  })
  .required({ userId: true, trackingId: true, domain: true });

export const insertPageViewSchema = createInsertSchema(pageViews)
  .pick({
    websiteId: true,
    visitorId: true,
    sessionId: true,
    url: true,
    path: true,
    title: true,
    referrer: true,
    userAgent: true,
    ip: true,
    browser: true,
    os: true,
    device: true,
    country: true,
    region: true,
    city: true,
    language: true,
    duration: true,
    bounced: true,
    entryPage: true,
    exitPage: true,
  })
  .required({ websiteId: true, url: true, path: true });

export const insertEventSchema = createInsertSchema(events)
  .pick({
    websiteId: true,
    visitorId: true,
    sessionId: true,
    eventType: true,
    eventCategory: true,
    eventAction: true,
    eventLabel: true,
    eventValue: true,
    url: true,
    path: true,
    elementId: true,
    elementClass: true,
    elementType: true,
    elementText: true,
    formData: true,
  })
  .required({ websiteId: true, eventType: true, url: true, path: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertAvailableSlot = z.infer<typeof insertAvailableSlotSchema>;
export type AvailableSlot = typeof availableSlots.$inferSelect;

export type InsertWebsiteAnalytics = z.infer<typeof insertWebsiteAnalyticsSchema>;
export type WebsiteAnalytics = typeof websiteAnalytics.$inferSelect;

export type InsertSocialMediaAccount = z.infer<typeof insertSocialMediaAccountSchema>;
export type SocialMediaAccount = typeof socialMediaAccounts.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Types for new tables
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

export type InsertShipment = z.infer<typeof insertShipmentSchema>;
export type Shipment = typeof shipments.$inferSelect;

export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;

export type InsertShippingProvider = z.infer<typeof insertShippingProviderSchema>;
export type ShippingProvider = typeof shippingProviders.$inferSelect;

// Types for website tracking and connections
export type InsertSocialConnection = z.infer<typeof insertSocialConnectionSchema>;
export type SocialConnection = typeof socialConnections.$inferSelect;

export type InsertEcommerceConnection = z.infer<typeof insertEcommerceConnectionSchema>;
export type EcommerceConnection = typeof ecommerceConnections.$inferSelect;

export type InsertTrackedWebsite = z.infer<typeof insertTrackedWebsiteSchema>;
export type TrackedWebsite = typeof trackedWebsites.$inferSelect;

export type InsertPageView = z.infer<typeof insertPageViewSchema>;
export type PageView = typeof pageViews.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;
