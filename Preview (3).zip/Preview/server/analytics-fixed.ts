/**
 * Fixed Analytics Handler for Lab AI
 * This file replaces the broken analytics handler in routes.ts
 */

import { Request, Response } from "express";
import { storage } from "./storage";

// Process analytics data from page views
export async function getWebsiteAnalytics(req: Request, res: Response) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  try {
    const websiteId = parseInt(req.params.id);
    const website = await storage.getTrackedWebsiteById(websiteId);
    
    if (!website) {
      return res.status(404).json({ message: "Website not found" });
    }
    
    // Verify the website belongs to the authenticated user
    if (website.userId !== req.user!.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    // Get query parameters for date range
    const start = req.query.start 
      ? new Date(req.query.start as string) 
      : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // Default to last 30 days
    
    const end = req.query.end 
      ? new Date(req.query.end as string) 
      : new Date();
    
    console.log(`Getting analytics for website ${websiteId} from ${start.toISOString()} to ${end.toISOString()}`);
    
    // Get actual page views and events
    const pageViews = await storage.getPageViewsByWebsite(websiteId, start, end);
    console.log(`Found ${pageViews.length} real page views for website ${websiteId}`);
    
    // If we have no real data, don't show sample data
    // Return empty analytics object
    if (pageViews.length === 0) {
      return res.json({
        uniqueVisitors: 0,
        pageViewCount: 0,
        bounceRate: 0,
        averageSessionDuration: 0,
        visitorsByDevice: [],
        visitorsByBrowser: [],
        visitorsByLocation: [],
        trafficByHour: Array.from({ length: 24 }, (_, i) => ({ hour: i, count: 0 })),
        trafficByDay: [],
        topPages: [],
        topReferrers: [],
        events: [],
        conversionRate: 0,
        comparisonStats: {
          visitorsChange: 0,
          pageViewsChange: 0,
          bounceRateChange: 0,
          durationChange: 0
        },
        timeframe: {
          start: start.toISOString(),
          end: end.toISOString()
        }
      });
    }
    
    // We have real data! Process it
    // Count unique visitors
    const visitorIds = pageViews.map(pv => pv.visitorId).filter(Boolean);
    const uniqueVisitors = new Set(visitorIds).size;
    
    // Group pageviews by URL
    const pagesByUrl = {};
    pageViews.forEach(pv => {
      const url = pv.path || '/';
      if (!pagesByUrl[url]) pagesByUrl[url] = 0;
      pagesByUrl[url]++;
    });
    
    // Group by referrer
    const referrerCounts = {};
    pageViews.forEach(pv => {
      if (pv.referrer) {
        let referrer = pv.referrer;
        try {
          const url = new URL(pv.referrer);
          referrer = url.hostname;
        } catch(e) {
          // Use referrer as-is
        }
        
        if (!referrerCounts[referrer]) referrerCounts[referrer] = 0;
        referrerCounts[referrer]++;
      }
    });
    
    // Group by browser
    const browserCounts = {};
    pageViews.forEach(pv => {
      const userAgent = pv.userAgent || '';
      let browser = 'Unknown';
      
      if (userAgent.includes('Chrome')) browser = 'Chrome';
      else if (userAgent.includes('Firefox')) browser = 'Firefox';
      else if (userAgent.includes('Safari')) browser = 'Safari';
      else if (userAgent.includes('Edge')) browser = 'Edge';
      else if (userAgent.includes('MSIE') || userAgent.includes('Trident')) browser = 'Internet Explorer';
      
      if (!browserCounts[browser]) browserCounts[browser] = 0;
      browserCounts[browser]++;
    });
    
    // Group by device type (simplified)
    const deviceCounts = {};
    pageViews.forEach(pv => {
      const userAgent = pv.userAgent || '';
      let device = 'Desktop';
      
      if (userAgent.includes('Mobile')) device = 'Mobile';
      else if (userAgent.includes('Tablet')) device = 'Tablet';
      
      if (!deviceCounts[device]) deviceCounts[device] = 0;
      deviceCounts[device]++;
    });
    
    // Hourly distribution
    const hourCounts = Array(24).fill(0);
    pageViews.forEach(pv => {
      if (pv.timestamp) {
        const hour = new Date(pv.timestamp).getHours();
        hourCounts[hour]++;
      }
    });
    
    // Format the data for response
    const formattedReferrers = Object.entries(referrerCounts)
      .map(([url, count]) => ({
        url,
        count: count as number,
        percentage: Math.round((count as number / pageViews.length) * 1000) / 10
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    const formattedBrowsers = Object.entries(browserCounts)
      .map(([browser, count]) => ({
        browser,
        count: count as number,
        percentage: Math.round((count as number / pageViews.length) * 1000) / 10
      }))
      .sort((a, b) => b.count - a.count);
    
    const formattedDevices = Object.entries(deviceCounts)
      .map(([device, count]) => ({
        device,
        count: count as number,
        percentage: Math.round((count as number / pageViews.length) * 1000) / 10
      }))
      .sort((a, b) => b.count - a.count);
    
    const formattedPages = Object.entries(pagesByUrl)
      .map(([url, count]) => ({
        url,
        count: count as number,
        bounceRate: 0,
        avgTime: 0
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    const trafficByHour = hourCounts.map((count, hour) => ({
      hour,
      count
    }));
    
    // Daily traffic
    const dailyData = {};
    pageViews.forEach(pv => {
      if (pv.timestamp) {
        const date = new Date(pv.timestamp).toISOString().split('T')[0];
        if (!dailyData[date]) {
          dailyData[date] = {
            pageViews: 0,
            visitors: new Set()
          };
        }
        
        dailyData[date].pageViews++;
        if (pv.visitorId) {
          dailyData[date].visitors.add(pv.visitorId);
        }
      }
    });
    
    const trafficByDay = Object.entries(dailyData).map(([date, data]) => ({
      date,
      pageViews: data.pageViews,
      visitors: data.visitors.size
    })).sort((a, b) => a.date.localeCompare(b.date));
    
    // Return the processed analytics
    return res.json({
      uniqueVisitors,
      pageViewCount: pageViews.length,
      bounceRate: 0, // Requires more complex session analysis
      averageSessionDuration: 0, // Requires more complex session analysis
      visitorsByDevice: formattedDevices,
      visitorsByBrowser: formattedBrowsers,
      visitorsByLocation: [], // Would need IP geolocation
      trafficByHour,
      trafficByDay,
      topPages: formattedPages,
      topReferrers: formattedReferrers,
      events: [], // Would need event data
      conversionRate: 0, // Would need conversion data
      comparisonStats: {
        visitorsChange: 0,
        pageViewsChange: 0,
        bounceRateChange: 0,
        durationChange: 0
      },
      timeframe: {
        start: start.toISOString(),
        end: end.toISOString()
      }
    });
  } catch (error) {
    console.error("Error getting website analytics:", error);
    res.status(500).json({ message: "Error retrieving analytics data" });
  }
}