/**
 * Jest setup file for Lab AI tests
 * This file runs before each test file to configure the test environment
 */

// Import test libraries
import '@testing-library/jest-dom';
import 'whatwg-fetch'; // Polyfill for fetch in tests

// Mock the environment variables
// This simulates the import.meta.env in Vite
window.import = {
  meta: {
    env: {
      DEV: true,
      MODE: 'test',
      VITE_STRIPE_PUBLIC_KEY: 'pk_test_mock_key',
      VITE_APP_VERSION: '1.0.0-test',
    }
  }
};

// Add global mocks and test configurations
global.ResizeObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

// Mock window.matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

// Suppress console errors during tests
const originalConsoleError = console.error;
console.error = (...args) => {
  if (
    typeof args[0] === 'string' && 
    (args[0].includes('ReactDOM.render is no longer supported') ||
     args[0].includes('act(...) is not supported in production builds'))
  ) {
    return;
  }
  originalConsoleError(...args);
};

// Clean up all mocks after each test
afterEach(() => {
  jest.clearAllMocks();
});

// Mock IntersectionObserver
global.IntersectionObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
  root: null,
  rootMargin: '',
  thresholds: [],
}));

// Extend Jest matchers
expect.extend({
  toBeValidDate(received) {
    const pass = received instanceof Date && !isNaN(received.getTime());
    return {
      pass,
      message: () => `expected ${received} to be a valid Date object`,
    };
  },
});