/**
 * Database check utility for Lab AI application
 * This module provides functions to check database health and run diagnostics
 */

import { pool, db } from './db';
import { sql } from 'drizzle-orm';

/**
 * Check database connectivity
 * @returns Promise resolving to a boolean indicating database health
 */
export async function checkDatabaseConnection(): Promise<boolean> {
  try {
    const client = await pool.connect();
    try {
      await client.query('SELECT 1 as health_check');
      return true;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Database health check failed:', error);
    return false;
  }
}

/**
 * Get database statistics
 * @returns Promise resolving to database statistics
 */
export async function getDatabaseStats(): Promise<any> {
  try {
    const client = await pool.connect();
    try {
      // Get schema statistics
      const schemaStats = await client.query(`
        SELECT 
          schemaname, 
          COUNT(*) as num_tables
        FROM 
          pg_tables 
        WHERE 
          schemaname NOT IN ('pg_catalog', 'information_schema')
        GROUP BY 
          schemaname
      `);
      
      // Get table sizes
      const tableSizes = await client.query(`
        SELECT 
          table_schema, 
          table_name, 
          pg_size_pretty(pg_total_relation_size('"' || table_schema || '"."' || table_name || '"')) as size
        FROM 
          information_schema.tables
        WHERE 
          table_schema NOT IN ('pg_catalog', 'information_schema')
        ORDER BY 
          pg_total_relation_size('"' || table_schema || '"."' || table_name || '"') DESC
        LIMIT 10
      `);
      
      // Get database size
      const dbSize = await client.query(`
        SELECT 
          pg_size_pretty(pg_database_size(current_database())) as db_size
      `);
      
      return {
        schemaStats: schemaStats.rows,
        tableSizes: tableSizes.rows,
        databaseSize: dbSize.rows[0].db_size
      };
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error getting database stats:', error);
    return null;
  }
}

/**
 * Run diagnostic queries on the database
 * @returns Promise resolving to diagnostic results
 */
export async function runDatabaseDiagnostics(): Promise<any> {
  try {
    // Check for long-running queries
    const longRunningQueries = await db.execute(sql`
      SELECT 
        pid, 
        now() - pg_stat_activity.query_start AS duration, 
        query, 
        state
      FROM 
        pg_stat_activity
      WHERE 
        (now() - pg_stat_activity.query_start) > interval '5 seconds'
        AND state = 'active'
        AND pid <> pg_backend_pid()
      ORDER BY 
        duration DESC
    `);
    
    // Check for table bloat
    const tableBloat = await db.execute(sql`
      SELECT
        schemaname, 
        tablename, 
        pg_size_pretty(wastedbytes) as bloat_size
      FROM (
        SELECT
          schemaname,
          tablename,
          (
            (data_total)::float8
            - (all_table_pages)::float8 * 8192
          ) AS wastedbytes
        FROM (
          SELECT
            schemaname,
            tablename,
            (case when schemaname = 'public' then data_length::float8 else 0 end) as data_total,
            n_live_tup,
            ceil((case when schemaname = 'public' then n_live_tup else 1000 end)::float8 / (
              (current_setting('block_size')::float8 - 
                (24 + 8 * (
                  coalesce(
                    (
                      select count(*)
                      from pg_stats s2
                      where s2.tablename = stat.tablename
                        and s2.schemaname = stat.schemaname
                        and s2.attname = columns.attname
                    ),
                    0
                  )
                )
              )
            )
          )) as all_table_pages
          FROM pg_stat_all_tables as stat
          JOIN information_schema.columns as columns
            ON columns.table_schema = stat.schemaname
            AND columns.table_name = stat.tablename
          JOIN pg_statio_all_tables as statio
            ON statio.relname = stat.relname
            AND statio.schemaname = stat.schemaname
          JOIN pg_class as pc
            ON pc.relname = stat.relname
          JOIN pg_namespace as pn
            ON pn.oid = pc.relnamespace
            AND pn.nspname = stat.schemaname
          GROUP BY schemaname, tablename, data_length, n_live_tup
        ) as inner_query
      ) as bloat_data
      WHERE wastedbytes > 1048576
      ORDER BY wastedbytes DESC
      LIMIT 10
    `);
    
    return {
      longRunningQueries: longRunningQueries,
      tableBloat: tableBloat
    };
  } catch (error) {
    console.error('Error running database diagnostics:', error);
    return null;
  }
}

/**
 * Check for database configuration issues
 * @returns Promise resolving to configuration issues
 */
export async function checkDatabaseConfiguration(): Promise<any> {
  try {
    const client = await pool.connect();
    try {
      // Get connection information
      const connectionInfo = await client.query(`
        SELECT 
          current_setting('max_connections') as max_connections,
          count(*) as current_connections
        FROM 
          pg_stat_activity
      `);
      
      // Get cache hit ratio
      const cacheHitRatio = await client.query(`
        SELECT 
          sum(heap_blks_read) as heap_read,
          sum(heap_blks_hit) as heap_hit,
          sum(heap_blks_hit) / (sum(heap_blks_hit) + sum(heap_blks_read)) as ratio
        FROM 
          pg_statio_user_tables
      `);
      
      return {
        connectionInfo: connectionInfo.rows[0],
        cacheHitRatio: cacheHitRatio.rows[0]
      };
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error checking database configuration:', error);
    return null;
  }
}