#!/bin/bash

# Script to run tests for Lab AI application

# Check if command argument is provided
if [ "$1" == "watch" ]; then
    echo "Running tests in watch mode..."
    npx jest --watch
elif [ "$1" == "coverage" ]; then
    echo "Running tests with coverage report..."
    npx jest --coverage
else
    echo "Running all tests..."
    npx jest
fi