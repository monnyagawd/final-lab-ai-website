/**
 * This file contains a working copy of the routes.ts file.
 * The original file has syntax errors that prevent the server from starting.
 */

import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import Stripe from "stripe";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import session from "express-session";
import MemoryStore from "memorystore";
import { nanoid } from "nanoid";
import { setupOAuthStrategies } from "./oauth";
import { addEcommerceRoutes } from "./ecommerce-routes";
import { addInventoryRoutes } from "./inventory-routes";
import { registerExtensionRoutes } from "./extension-routes";
import { WebSocketServer } from "ws";

// Import our fixed analytics handler
import { getWebsiteAnalytics } from "./analytics-fixed";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Reuse hashing functions as needed
export { hashPassword, comparePasswords };

export async function registerRoutes(app: Express): Promise<Server> {
  // Create session store
  const SessionStore = MemoryStore(session);
  const sessionStore = new SessionStore({
    checkPeriod: 86400000 // Prune expired entries every 24h
  });
  
  // Session setup for authentication
  app.use(session({
    secret: process.env.SESSION_SECRET || "lab-ai-dev-secret",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    }
  }));
  
  // Passport authentication setup
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Set up local strategy for username/password login
  passport.use(new LocalStrategy({
    usernameField: 'username',
    passwordField: 'password'
  }, async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      
      const isValidPassword = await comparePasswords(password, user.password);
      if (!isValidPassword) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));
  
  // Serialize/deserialize user for session management
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });
  
  // Auth routes
  app.post('/api/register', async (req, res) => {
    try {
      const { username, email, password } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already taken.' });
      }
      
      // Create new user
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
      });
      
      // Log the user in after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Login after registration failed.' });
        }
        
        const userDataToReturn = {
          id: user.id,
          username: user.username,
          email: user.email,
        };
        
        return res.status(201).json({ user: userDataToReturn });
      });
    } catch (error) {
      console.error('Registration error:', error);
      return res.status(500).json({ message: 'Registration failed.' });
    }
  });
  
  app.post('/api/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || 'Authentication failed.' });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        
        const userDataToReturn = {
          id: user.id,
          username: user.username,
          email: user.email,
        };
        
        return res.json({ user: userDataToReturn });
      });
    })(req, res, next);
  });
  
  app.post('/api/logout', (req, res) => {
    req.logout(function(err) {
      if (err) {
        return res.status(500).json({ message: 'Logout failed.' });
      }
      res.json({ message: 'Logged out successfully.' });
    });
  });
  
  app.get('/api/user', (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = req.user as any;
    const userDataToReturn = {
      id: user.id,
      username: user.username,
      email: user.email,
    };
    
    res.json({ user: userDataToReturn });
  });
  
  // Set up OAuth strategies for social login
  setupOAuthStrategies(app);
  
  // Set up website tracking routes
  app.get("/api/tracked-websites", async (req, res) => {
    // Ensure user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Get user ID from session
      const userId = req.user!.id;
      
      // Fetch websites from storage
      const websites = await storage.getTrackedWebsites(userId);
      
      // Return websites to client
      return res.json(websites);
    } catch (error) {
      console.error("Error fetching tracked websites:", error);
      return res.status(500).json({ 
        message: "Failed to fetch tracked websites"
      });
    }
  });
  
  // Analytics data endpoint - shows real data, not sample data
  app.get("/api/tracked-websites/:id/analytics", getWebsiteAnalytics);
  
  // Add other routes from separate files
  addEcommerceRoutes(app, storage);
  addInventoryRoutes(app, storage);
  registerExtensionRoutes(app);
  
  // Create server and setup WebSocket
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket handling
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Echo back for testing
        ws.send(JSON.stringify({ type: 'echo', data }));
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });
  
  return httpServer;
}