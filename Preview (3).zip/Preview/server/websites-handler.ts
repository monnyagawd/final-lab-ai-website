/**
 * Websites Tracking Handler
 * Responsible for listing and managing websites
 */

import { Request, Response } from "express";
import { storage } from "./storage";

// List all tracked websites for a user
export async function listTrackedWebsites(req: Request, res: Response) {
  // Ensure user is authenticated
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  try {
    // Get user ID from session
    const userId = req.user!.id;
    
    // Fetch websites from storage
    const websites = await storage.getTrackedWebsites(userId);
    
    // Return websites to client
    return res.json(websites);
  } catch (error) {
    console.error("Error fetching tracked websites:", error);
    return res.status(500).json({ 
      message: "Failed to fetch tracked websites"
    });
  }
}