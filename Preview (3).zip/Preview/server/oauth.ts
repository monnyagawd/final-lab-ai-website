import passport from 'passport';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import { Strategy as TwitterStrategy } from 'passport-twitter';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as OAuth2Strategy } from 'passport-oauth2';
import { Express } from 'express';
import { storage } from './storage';

interface SocialProfile {
  id: string;
  displayName: string;
  username?: string;
  photos?: Array<{ value: string }>;
  provider: string;
  _json?: any;
}

export function setupOAuthStrategies(app: Express) {
  // For now, we'll just set up placeholder routes for OAuth
  console.log('OAuth setup pending - API keys not configured');
  
  // Placeholder routes for OAuth services
  app.get('/auth/facebook', (req, res) => {
    res.redirect('/dashboard/social-media?error=oauth_not_configured');
  });
  
  app.get('/auth/twitter', (req, res) => {
    res.redirect('/dashboard/social-media?error=oauth_not_configured');
  });
  
  app.get('/auth/google', (req, res) => {
    res.redirect('/dashboard/social-media?error=oauth_not_configured');
  });
  
  // Add routes to handle manual connections as fallback
  setupManualConnectionRoutes(app);
  
  /* 
  // The code below is kept as a reference for when API keys are added
  
  // Check for necessary environment variables
  const requiredSecrets: Record<string, string[]> = {
    facebook: ['FACEBOOK_APP_ID', 'FACEBOOK_APP_SECRET'],
    twitter: ['TWITTER_CONSUMER_KEY', 'TWITTER_CONSUMER_SECRET'],
    google: ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'],
  };
  
  // Setup Facebook strategy
  if (process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET) {
    passport.use(new FacebookStrategy({
      clientID: process.env.FACEBOOK_APP_ID,
      clientSecret: process.env.FACEBOOK_APP_SECRET,
      callbackURL: "/auth/facebook/callback",
      profileFields: ['id', 'displayName', 'photos', 'email', 'name', 'profileUrl'],
    }, async (accessToken, refreshToken, profile, done) => {
      try {
        const userData = await handleSocialLogin('facebook', profile, accessToken, refreshToken);
        return done(null, userData);
      } catch (error) {
        return done(error as Error);
      }
    }));
    
    app.get('/auth/facebook', passport.authenticate('facebook', { 
      scope: ['email', 'public_profile', 'pages_show_list', 'instagram_basic', 'pages_read_engagement'] 
    }));
    
    app.get('/auth/facebook/callback',
      passport.authenticate('facebook', { 
        failureRedirect: '/dashboard/social-media?error=facebook_auth_failed'
      }),
      (req, res) => {
        res.redirect('/dashboard/social-media?success=facebook_connected');
      }
    );
  }
  
  // Setup Twitter strategy
  if (process.env.TWITTER_CONSUMER_KEY && process.env.TWITTER_CONSUMER_SECRET) {
    passport.use(new TwitterStrategy({
      consumerKey: process.env.TWITTER_CONSUMER_KEY,
      consumerSecret: process.env.TWITTER_CONSUMER_SECRET,
      callbackURL: "/auth/twitter/callback",
      includeEmail: true
    }, async (token, tokenSecret, profile, done) => {
      try {
        const userData = await handleSocialLogin('twitter', profile, token, tokenSecret);
        return done(null, userData);
      } catch (error) {
        return done(error as Error);
      }
    }));
    
    app.get('/auth/twitter', passport.authenticate('twitter'));
    
    app.get('/auth/twitter/callback',
      passport.authenticate('twitter', { 
        failureRedirect: '/dashboard/social-media?error=twitter_auth_failed'
      }),
      (req, res) => {
        res.redirect('/dashboard/social-media?success=twitter_connected');
      }
    );
  }
  
  // Setup Google strategy
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    passport.use(new GoogleStrategy({
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: "/auth/google/callback"
    }, async (accessToken, refreshToken, profile, done) => {
      try {
        const userData = await handleSocialLogin('google', profile, accessToken, refreshToken);
        return done(null, userData);
      } catch (error) {
        return done(error as Error);
      }
    }));
    
    app.get('/auth/google', passport.authenticate('google', { 
      scope: ['profile', 'email', 'https://www.googleapis.com/auth/youtube.readonly'] 
    }));
    
    app.get('/auth/google/callback',
      passport.authenticate('google', { 
        failureRedirect: '/dashboard/social-media?error=google_auth_failed'
      }),
      (req, res) => {
        res.redirect('/dashboard/social-media?success=google_connected');
      }
    );
  }
  */
}

async function handleSocialLogin(
  provider: string, 
  profile: SocialProfile, 
  accessToken: string, 
  refreshToken: string
) {
  if (!profile.id) {
    throw new Error(`Invalid profile data from ${provider}`);
  }
  
  const accountId = profile.id;
  const accountName = profile.displayName || profile.username || `${provider} user`;
  
  // Calculate token expiry (default: 60 days from now)
  const tokenExpiry = new Date();
  tokenExpiry.setDate(tokenExpiry.getDate() + 60);
  
  // In a real implementation, we'd associate this with the current user
  // For now, we'll use user ID 1 as a placeholder
  const userId = 1; // This should be the ID of the authenticated user
  
  // Check if this account is already connected
  const existingAccount = await storage.getSocialMediaAccountByPlatform(userId, provider);
  
  if (existingAccount) {
    // Update the existing account
    const updatedAccount = await storage.updateSocialMediaAccount(existingAccount.id, {
      accountName,
      accessToken,
      refreshToken,
      tokenExpiry: tokenExpiry.toISOString()
    });
    
    return { userId, platformAccount: updatedAccount };
  } else {
    // Create initial followers history
    const initialFollowers = "0"; 
    const currentDate = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
    const followersHistory = JSON.stringify([{ 
      date: currentDate, 
      count: initialFollowers 
    }]);
    
    // Create a new account
    const newAccount = await storage.createSocialMediaAccount({
      userId,
      platform: provider,
      accountId,
      accountName,
      accessToken,
      refreshToken,
      tokenExpiry: tokenExpiry.toISOString(),
      followers: initialFollowers,
      following: "0",
      engagement: "0",
      growthRate: "0",
      followersHistory
    });
    
    return { userId, platformAccount: newAccount };
  }
}

function setupManualConnectionRoutes(app: Express) {
  // This route already exists in routes.ts but we'll keep it here for reference
  // app.post("/api/dashboard/link-social", async (req, res) => {...});
}