import { useEffect, useState } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, CheckCircle, RefreshCw, ExternalLink, CreditCard } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { format } from 'date-fns';

interface Payment {
  id: string;
  amount: number;
  status: string;
  date: string;
  paymentMethod: string;
  description: string;
}

interface Subscription {
  id: string;
  planName: string;
  status: string;
  amount: number;
  interval: string;
  startDate: string;
  nextBillingDate: string;
}

export default function PaymentHistory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('payments');
  
  // Fetch payment history
  const {
    data: payments,
    isLoading: paymentsLoading,
    error: paymentsError,
    refetch: refetchPayments
  } = useQuery({
    queryKey: ['/api/payments/history'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/payments/history');
      return res.json();
    },
    enabled: !!user
  });
  
  // Fetch subscription data
  const {
    data: subscription,
    isLoading: subscriptionLoading,
    error: subscriptionError,
    refetch: refetchSubscription
  } = useQuery({
    queryKey: ['/api/subscription'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/subscription');
      return res.json();
    },
    enabled: !!user
  });
  
  // Cancel subscription mutation
  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/subscription/cancel');
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Subscription Canceled',
        description: 'Your subscription has been canceled successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/subscription'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to Cancel Subscription',
        description: error.message || 'An error occurred while canceling your subscription.',
        variant: 'destructive',
      });
    }
  });
  
  // Handle subscription cancellation
  const handleCancelSubscription = () => {
    if (confirm('Are you sure you want to cancel your subscription? This action cannot be undone.')) {
      cancelSubscriptionMutation.mutate();
    }
  };
  
  // Format currency helper
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };
  
  // Format date helper
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM d, yyyy');
    } catch (error) {
      return dateString;
    }
  };
  
  // Get payment status badge
  const getPaymentStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'succeeded':
      case 'paid':
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Successful
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
            Processing
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <AlertCircle className="w-3 h-3 mr-1" />
            Failed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };
  
  // Get subscription status badge
  const getSubscriptionStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Active
          </span>
        );
      case 'past_due':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <AlertCircle className="w-3 h-3 mr-1" />
            Past Due
          </span>
        );
      case 'canceled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            Canceled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };
  
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Billing & Subscription</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-8">
          <TabsTrigger value="payments">Payment History</TabsTrigger>
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
        </TabsList>
        
        <TabsContent value="payments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>View your recent payment activity</CardDescription>
            </CardHeader>
            
            <CardContent>
              {paymentsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : paymentsError ? (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    Failed to load payment history. Please try again later.
                  </AlertDescription>
                </Alert>
              ) : payments?.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[600px] divide-y divide-border">
                    <thead>
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Date</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Description</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Amount</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-background divide-y divide-border">
                      {payments.map((payment: Payment) => (
                        <tr key={payment.id}>
                          <td className="px-4 py-4 whitespace-nowrap text-sm">
                            {formatDate(payment.date)}
                          </td>
                          <td className="px-4 py-4 text-sm">
                            {payment.description}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">
                            {formatCurrency(payment.amount)}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm">
                            {getPaymentStatusBadge(payment.status)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <div className="mb-4">
                    <CreditCard className="h-12 w-12 mx-auto text-muted-foreground/50" />
                  </div>
                  <p>No payment history found</p>
                  <p className="text-sm mt-1">Your payment history will appear here once you make a purchase</p>
                </div>
              )}
            </CardContent>
            
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                onClick={() => refetchPayments()}
                disabled={paymentsLoading}
              >
                {paymentsLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="subscription" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Subscription Details</CardTitle>
              <CardDescription>Manage your subscription plan</CardDescription>
            </CardHeader>
            
            <CardContent>
              {subscriptionLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : subscriptionError ? (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    Failed to load subscription details. Please try again later.
                  </AlertDescription>
                </Alert>
              ) : subscription ? (
                <div className="space-y-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Plan</h3>
                      <p className="text-lg font-medium">{subscription.planName}</p>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                      <div>{getSubscriptionStatusBadge(subscription.status)}</div>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Price</h3>
                      <p className="text-lg font-medium">
                        {formatCurrency(subscription.amount)}/{subscription.interval}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Started On</h3>
                      <p className="text-lg font-medium">{formatDate(subscription.startDate)}</p>
                    </div>
                    
                    <div className="space-y-2 sm:col-span-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Next Billing Date</h3>
                      <p className="text-lg font-medium">{formatDate(subscription.nextBillingDate)}</p>
                    </div>
                  </div>
                  
                  {subscription.status.toLowerCase() === 'active' && (
                    <>
                      <hr className="my-6" />
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Subscription Management</h3>
                        
                        <div className="flex flex-wrap gap-4">
                          <Button
                            variant="outline"
                            onClick={() => window.open('https://dashboard.stripe.com/billing', '_blank')}
                          >
                            <ExternalLink className="mr-2 h-4 w-4" />
                            Update Payment Method
                          </Button>
                          
                          <Button
                            variant="destructive"
                            onClick={handleCancelSubscription}
                            disabled={cancelSubscriptionMutation.isPending}
                          >
                            {cancelSubscriptionMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Canceling...
                              </>
                            ) : (
                              'Cancel Subscription'
                            )}
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <div className="mb-4">
                    <CreditCard className="h-12 w-12 mx-auto text-muted-foreground/50" />
                  </div>
                  <p>No active subscription</p>
                  <p className="text-sm mt-1">Subscribe to one of our plans to get started</p>
                </div>
              )}
            </CardContent>
            
            <CardFooter className="flex justify-end">
              <Button 
                variant="outline" 
                onClick={() => refetchSubscription()}
                disabled={subscriptionLoading}
              >
                {subscriptionLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}