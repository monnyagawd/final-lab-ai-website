import { pgTable, serial, text, integer, timestamp, boolean, json } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';
import { users } from './schema';

// Social Media Integration
export const socialConnections = pgTable('social_connections', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  platform: text('platform'), // e.g., 'twitter', 'instagram', 'facebook'
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  tokenExpiry: timestamp('token_expiry'),
  platformUserId: text('platform_user_id'),
  username: text('username'),
  profileUrl: text('profile_url'),
  isConnected: boolean('is_connected').default(true),
  lastSynced: timestamp('last_synced'),
  metadata: json('metadata')
});

// E-commerce Integrations
export const ecommerceConnections = pgTable('ecommerce_connections', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  platform: text('platform'), // e.g., 'shopify', 'woocommerce'
  shopName: text('shop_name'),
  shopDomain: text('shop_domain'),
  apiKey: text('api_key'),
  apiSecret: text('api_secret'),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  isConnected: boolean('is_connected').default(true),
  lastSynced: timestamp('last_synced'),
  metadata: json('metadata')
});

// Analytics Websites Tracking
export const trackedWebsites = pgTable('tracked_websites', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  domain: text('domain'),
  name: text('name'),
  trackingId: text('tracking_id'),
  createdAt: timestamp('created_at').defaultNow(),
  isActive: boolean('is_active').default(true)
});

// Analytics Data
export const pageViews = pgTable('page_views', {
  id: serial('id').primaryKey(),
  websiteId: integer('website_id').references(() => trackedWebsites.id),
  url: text('url'),
  title: text('title'),
  referrer: text('referrer'),
  userAgent: text('user_agent'),
  ipAddress: text('ip_address'),
  timestamp: timestamp('timestamp'),
  sessionId: text('session_id'),
  visitorId: text('visitor_id')
});

export const events = pgTable('events', {
  id: serial('id').primaryKey(),
  websiteId: integer('website_id').references(() => trackedWebsites.id),
  eventName: text('event_name'),
  eventData: json('event_data'),
  url: text('url'),
  timestamp: timestamp('timestamp'),
  sessionId: text('session_id'),
  visitorId: text('visitor_id')
});

// Create insert schemas with Zod
export const insertSocialConnectionSchema = createInsertSchema(socialConnections);
export const insertEcommerceConnectionSchema = createInsertSchema(ecommerceConnections);
export const insertTrackedWebsiteSchema = createInsertSchema(trackedWebsites);
export const insertPageViewSchema = createInsertSchema(pageViews);
export const insertEventSchema = createInsertSchema(events);

// Create types
export type SocialConnection = typeof socialConnections.$inferSelect;
export type InsertSocialConnection = z.infer<typeof insertSocialConnectionSchema>;

export type EcommerceConnection = typeof ecommerceConnections.$inferSelect;
export type InsertEcommerceConnection = z.infer<typeof insertEcommerceConnectionSchema>;

export type TrackedWebsite = typeof trackedWebsites.$inferSelect;
export type InsertTrackedWebsite = z.infer<typeof insertTrackedWebsiteSchema>;

export type PageView = typeof pageViews.$inferSelect;
export type InsertPageView = z.infer<typeof insertPageViewSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;