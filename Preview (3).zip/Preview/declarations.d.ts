/**
 * Type declarations for external modules without their own type definitions
 */

declare module 'passport-facebook' {
  import { Strategy as PassportStrategy } from 'passport';
  export class Strategy extends PassportStrategy {
    constructor(options: any, verify: any);
  }
}

declare module 'passport-twitter' {
  import { Strategy as PassportStrategy } from 'passport';
  export class Strategy extends PassportStrategy {
    constructor(options: any, verify: any);
  }
}

declare module 'passport-google-oauth20' {
  import { Strategy as PassportStrategy } from 'passport';
  export class Strategy extends PassportStrategy {
    constructor(options: any, verify: any);
  }
}

declare module 'passport-oauth2' {
  import { Strategy as PassportStrategy } from 'passport';
  export class Strategy extends PassportStrategy {
    constructor(options: any, verify: any);
  }
}

/**
 * Declarations for Lab AI project specific types that might not be 
 * properly inferred by TypeScript
 */

// Extend the Express User interface
declare namespace Express {
  interface User {
    id: number;
    username: string;
    email: string;
    firstName?: string;
    lastName?: string;
    companyName?: string;
    websiteName?: string;
    stripeCustomerId?: string;
    stripeSubscriptionId?: string;
    [key: string]: any;
  }
}